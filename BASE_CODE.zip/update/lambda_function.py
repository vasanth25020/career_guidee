import sys
import logging
import rds_config
import pymysql
import json
from bson import json_util
import hashlib
#rds settings
rds_host  = "kcommerce.c0qatg8z8lnd.ap-south-1.rds.amazonaws.com"
name = rds_config.db_username
password = rds_config.db_password
db_name = rds_config.db_name

logger = logging.getLogger()
logger.setLevel(logging.INFO)



try:
    print(db_name)
    
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit()

logger.info("SUCCESS: Connection to RDS MySQL instance succeeded")


def lambda_handler(event, context):
    
    print(event)
    print(event['body'])
    conn = pymysql.connect(host=rds_host, user=name, passwd=password, db=db_name, connect_timeout=10)
    data = json.loads(event['body'])
    
    
    
    #user_data = [mobile, pss]
    sql_marketer_data_updt = "UPDATE  NETWORK_MARKETER.MARKETER  SET MARKETER_NAME='{}', MARKETER_MOBILE_NUMBER='{}', MARKETER_MAIL_ID='{}', AADHAR_NUMBER={}, REFERRAL_CODE={}, PASSWORD='{}',IS_ACTIVE='{}',PINCODE='{}',REFERRED_BY='{}' WHERE MARKETER_ID={}".format(data['marketer_name'],
     data['marketer_mobile'], data['marketer_mail_id'], data['marketer_aadhar_no'],  data['marketer_referral_code'],hashlib.sha1(data['password']),data['is_active'],data['pincode'],data['refered_by'],data['marketer_id'])
   
    
    print(sql_marketer_data_updt)
    
    with conn.cursor() as cur:
        cur.execute(sql_marketer_data_updt)
        print("Executed Successfully")
        conn.commit()
        
        return {
            "statusCode": 200,
            "headers": {
                "Content-Type": "application/json"
            },
            "body": json.dumps({
                        "statusCode": 200,
                        "responseMessage" : "MARKETER UPDATED SUCCESSFULLY",
                        "response" :"MARKETER UPDATED SUCCESSFULLY"
                    })
        }
        
        
    