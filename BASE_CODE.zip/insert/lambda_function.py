import sys
import logging
import rds_config
import pymysql
import json
from bson import json_util

#rds settings
rds_host  = "kcommerce.c0qatg8z8lnd.ap-south-1.rds.amazonaws.com"
name = rds_config.db_username
password = rds_config.db_password
db_name = rds_config.db_name

logger = logging.getLogger()
logger.setLevel(logging.INFO)



try:
    print(db_name)
    
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit()

logger.info("SUCCESS: Connection to RDS MySQL instance succeeded")


def lambda_handler(event, context):
    
    print(event)
    print(event['body'])
    
    data = json.loads(event['body'])
    try:
        conn = pymysql.connect(host=rds_host, user=name, passwd=password, db=db_name, connect_timeout=10)
        with conn.cursor() as cur:   
            args = (data['marketer_name'],data['marketer_mobile'],data['marketer_mail_id'],data['marketer_aadhar_no'],data['marketer_referral_code'],
                            data['password'],data['is_active'],data['pincode'],data['refered_by'])    
            result_args =cur.callproc('SP_INSERT_NETWORK_MARKETER',args)
            row_headers=[x[0] for x in cur.description]
            rv = cur.fetchall()
            json_data=[]
            for result in rv:
                json_data.append(dict(zip(row_headers,result)))
        
        if json_data['response'] is 'MARKETER MOBILE NUMBER EXISTS':
            return {
                    "statusCode": 400,
                    "headers": {
                    "Content-Type": "application/json",
                    'Access-Control-Allow-Headers': 'Content-Type',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT,DELETE'
                    },
                    "body": json.dumps({
                        "statusCode": 400,
                        "responseMessage" : "MARKETER MOBILE NUMBER EXISTS",
                        "response" :"MARKETER MOBILE NUMBER EXISTS"
                    })
                    
                }   
        else:
            return {
                    "statusCode": 400,
                    "headers": {
                    "Content-Type": "application/json",
                    'Access-Control-Allow-Headers': 'Content-Type',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT,DELETE'
                    },
                    "body": json.dumps({
                        "statusCode": 200,
                        "responseMessage" : "MARKETER CREATED SUCCESSFULLY",
                        "response" :"MARKETER CREATED SUCCESSFULLY"
                    })
                    
                }   
    
    except pymysql.MySQLError as e:
        logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
        logger.error(e)
        