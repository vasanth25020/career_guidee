import sys
import logging
import rds_config
import pymysql
import json

# rds settings
rds_host = "kcommerce.c0qatg8z8lnd.ap-south-1.rds.amazonaws.com"
name = rds_config.db_username
password = rds_config.db_password
db_name = rds_config.db_name

logger = logging.getLogger()
logger.setLevel(logging.INFO)

try:
    print(db_name)

except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit()

logger.info("SUCCESS: Connection to RDS MySQL instance succeeded")


def lambda_handler(event, context):
    print(event)
    conn = pymysql.connect(host=rds_host, user=name, passwd=password, db=db_name, connect_timeout=10)
    marketer_id = event['queryStringParameters']['marketer_bank_id']

    sql = "DELETE FROM NETWORK_MARKETER.MARKETER_BANK_DETAILS WHERE MARK_BANK_ID='{}'".format(marketer_id)
    print(sql)

    with conn.cursor() as cur:
        cur.execute(sql)
        print("Executed Successfully")
        conn.commit()

        return {
            "statusCode": 200,
            "headers": {
                "Content-Type": "application/json"
            },
            "body": json.dumps({"status": "success"})
        }
    conn.close()




