#config file containing credentials for RDS MySQL instance
db_username = "admin"
db_password = "kcommerce@123"
db_name = "NETWORK_MARKETER"