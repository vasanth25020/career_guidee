Index
   It is one of the performance tuning method.
   It is a schema object
   Data Dictionary Table:user_indexes(UNIQUENESS) | user_ind_columns
   
  
--Types of Index

    Unique Index
          Get Create at the time of  Creating PK/UK
		  
	Non Unique Index
	      we need to create it.
		      Btree Index
			  Bitmap Index
			  Function Based Index
              Reverse key Index
              ---Clustered Index | IOT

SET AUTOT ON

SQL> SELECT employee_id,first_name,hire_date,salary,department_id
2      FROM employees
3     WHERE employee_id=100;

CREATE TABLE ind_employees AS SELECT * FROM employees;

SELECT employee_id,first_name,hire_date,salary,department_id
    FROM employees
  WHERE employee_id=100;



-->--Btree index
    Binary Tree Index
    created in High Cardinality column
    Default Index
   
   employee_id PAN_Number  Adhar

CREATE INDEX IND_01
ON ind_employees(employee_id) 


-->--BitMap Index 
     
	 create in low casrdinality column

CREATE BITMAP INDEX IND_02
ON employees_tb(genter);


-->--Function Based Index
 
    SELECT * FROM employees
      WHERE LOWER(first_name)='steven';

    CREATE INDEX IND_02
    ON employees(LOWER(first_name));

    CREATE INDEX IND_02
    ON employees(salary*12);


--Revers Key index

  CREATE INDEX OND_04
  ON students(total)REVERSE;

CREATE INDEX IND_01 ON ind_employees(employee_id);
CREATE BITMAP INDEX IND_02 ON int_employees(genter);   
CREATE INDEX IND_03 ON ind_employees(UPPER(first_name));
CREATE INDEX IND_04 ON students(total) REVERSE;


status

     when to use index?       when not to use index?

---  WHERE       	          Not used in WHERE clause

---  if the table contains    less in volume
     Huge volume of records 
	 10 Lahs

---  result | <10% | <4%       >10%

---  DML operations Dont prefer index 
  
ALTER TABLE Index_name REBUILD;  