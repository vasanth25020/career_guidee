--Analytical Function

   MIN( )   OVER( )
   MAX( )   OVER( )
   SUM( )   OVER( )
   COUNT( ) OVER( )
   AVG( )   OVER( )
   FIRST_VALUE( )
   LAST_VALUE( )
   RANK( )
   DENSE_RANK( )
   LEAD( )
   LAG( )
   LISTAGG( )       --11g
   
   PARTITION BY | ORDER BY
   
SELECT employee_id, first_name, hire_date, salary
     , MAX(salary) OVER( ) max_sal
  FROM employees;

SELECT employee_id, first_name, hire_date, salary
     , SUM(salary) OVER( ) total_sal
  FROM employees;

SELECT employee_id, first_name, hire_date, salary
     , COUNT(employee_id) OVER( ) no_of_emp
 FROM employees;
 
 SELECT employee_id, first_name, department_id
      , FIRST_VALUE(first_name) OVER(PARTITION BY department_id)  first_val
      , LAST_VALUE(first_name) OVER( )	last_val
  FROM employees;

SELECT employee_id
     , first_name, salary
     , department_id
     , salary
     , RANK( ) OVER(ORDER BY salary DESC) Rank
     , DENSE_RANK( ) OVER(ORDER BY salary DESC) dense_rank
   FROM employees;

--Nth Maximum salary
SELECT * FROM
(
SELECT employee_id
     , first_name
     , department_id
     , salary
	 , RANK( ) OVER(ORDER BY salary DESC) Rank
     , DENSE_RANK( ) OVER(ORDER BY salary DESC) dense_rank
   FROM employees;
 ) WHERE dense_rank = 3;
 
--Display 2nd maximum salary from each department

11g LISTAGG

1  A
1  B
1  C
2  L
2  M
3  K
3  R
3  S

1 A,B,C
2 L,M,
3 K,R,S

CREATE TABLE test_tb
( department_id NUMBER, name VARCHAR2(30));

BEGIN
INSERT INTO test_table VALUES(10,'Stevan');
INSERT INTO test_table VALUES(20,'Neena');
INSERT INTO test_table VALUES(20,'Abi');   
INSERT INTO test_table VALUES(20,'Alex');
INSERT INTO test_table VALUES(20,'Alex');
INSERT INTO test_table VALUES(30,'Rahul');
INSERT INTO test_table VALUES(30,'John');
INSERT INTO test_table VALUES(30,'Saravanan');
INSERT INTO test_table VALUES(30,'Karthik');
INSERT INTO test_table VALUES(40,'Ram');
END;
/