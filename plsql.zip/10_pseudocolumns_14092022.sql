pseudocolumns

	it is not a column inside the table but it just act a column 
	Mostly used in PLSQL
	
	USER
	UID
	SYSDATE       --14-SEP-22
	SYSTIMESTAMP  --14-SEP-22 11.50.38.448000 AM +05:30
	              --SYSDATE=TRUNC(SYSTIMESTAMP)
	ROWNUM
	ROWID
	
	--sequence related pseudo columns 
	NEXTVAL 
	CURRVAL
	LEVEL
	ORA_ROWSCN
	
SELECT USER, UID FROM dual;

SELECT SYSDATE, SYSTIMESTAMP FROM dual;

CREATE TABLE comp_tb
( cmp_id     NUMBER
, c_name VARCHAR2(30)
, req_by VARCHAR2(30)
, req_dttm TIMESTAMP
);

BEGIN
INSERT INTO comp_tb vcalues(1001,'Name_01', USER, SYSTIMESTAMP);
INSERT INTO comp_tb vcalues(1001,'Name_02', USER, SYSTIMESTAMP);
INSERT INTO comp_tb vcalues(1001,'Name_03', USER, SYSTIMESTAMP);
INSERT INTO comp_tb vcalues(1001,'Name_04', USER, SYSTIMESTAMP);
INSERT INTO comp_tb vcalues(1001,'Name_05', USER, SYSTIMESTAMP);
END;
/

SELECT * FROM comp_tb
  WHERE TRUNC(req_dttm)=TRUNC(SYSTIMESTAMP);
  
  ROWNUM
    -- generate Unique Number at Runtime
	-- Get Generate Before Execution of ORDER BY Clause

SELECT ROWNUM,D.* FROM departments d;
SELECT ROWNUM,D.* FROM departments d WHERE ROWNUM =  1; 
SELECT ROWNUM,D.* FROM departments d WHERE ROWNUM <= 5;
SELECT ROWNUM,D.* FROM departments d WHERE ROWNUM <  5;

--SELECT ROWNUM,d.* FROM departments d WHERE ROWNUM = 5;
--no rows selected

SELECT ROWNUM, d. * FROM departments d ORDER BY department_name ASC;

--Query to get 5th record 

SELECT *
  FROM (SELECT ROWNUM rn,d.*FROM departments d WHERE ROWNUM <= 5)
 WHERE rn = 5;
 
 --How to get Nth Maximum salary 
 
 SELECT MAX(salry) FROM employees;
 
 SELECT MAX(salary) FROM employees
  WHERE salary < (SELECT MAX(salary) FROM employees);
  
SELECT *
  FROM ( SELECT ROWNUM  rnk, salary
	       FROM ( SELECT DISTINCT salary 
		             FROM employees
		         ORDER BY salry DESC)
	    )
WHERE rnk=5;

SELECT MIN(salary)
  FROM ( SELECT ROWNUM rnk, salary
           FROM ( SELECT DISTINCT salary
		            FROM employees
		        ORDER BY salary DESC)
		WHERE ROWNUM <= 5
		);
		
--Top 5 salary 
SELECT ROWNUM, salary 
  FROM ( SELECT DISTINCT salary
           FROM employees
		 ORDER BY salary DESC)
		WHERE ROWNUM <= 5;
		
--ROWID
    It is a unique Address for each and every row in Orcle
    Length : 18
    If you fetch any row based on ROWID means it will be faster

SELECT ROWID, d.*FROM departments d;

--SELECT * FROM departments WHERE ROWID = 'AAAC8/AAEAAAAA3AAA';

--Last Iserted Row 
SELECT ROWID, d.*
  FROM departments d
 WHERE ROWID = (SELECT MAX(ROWID) FROM depatments);
 
 --First Inserted Row
 SELECT ROWID, d.*
   FROM departments d
  WHERE ROWID = (SELECT MIN(ROWID) FROM departments);


CREATE TABLE test_delete(name VARCHAR2(30));

BEGIN
   INSERT INTON test_delete VALUES('Murugappan');  
   INSERT INTON test_delete VALUES('Murugappan');	
   INSERT INTON test_delete VALUES('Rakesh');
   INSERT INTON test_delete VALUES('Rahul');
   INSERT INTON test_delete VALUES('Rahul');	  
   INSERT INTON test_delete VALUES('Rahul');
END;
/


DELETE FROM test_delete
  WHERE ROWID NOT IN (SELECT MAX(rowid) FROM test_delete GROUP BY name);
  
ORA_ROWSCN

SCN--System Change Number 














