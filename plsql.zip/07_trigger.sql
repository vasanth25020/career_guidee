Trigger (_trg) | High level Constraint


DROP TABLE t1;
DROP TABLE t2;

CREATE TABLE t1(id NUMBER);
CREATE TABLE t2(id NUMBER);


CREATE OR REPLACE TRIGGER t1_trg
AFTER INSERT OR UPDATE OR DELETE
ON t1
BEGIN
  INSERT INTO t2 VALUES(1);
END t1_trg;
/

CREATE OR REPLACE TRIGGER t1_trg
AFTER INSERT
ON t1
FOR EACH ROW
BEGIN
  INSERT INTO t2 VALUES(:new.id);
END t1_trg;
/

CREATE OR REPLACE TRIGGER t1_trg
AFTER INSERT OR UPDATE OR DELETE
ON t1
FOR EACH ROW
BEGIN
  INSERT INTO t2 VALUES(1);
END t1_trg;
/


CREATE OR REPLACE TRIGGER t1_trg
AFTER INSERT OR UPDATE OR DELETE
ON t1
FOR EACH ROW
BEGIN

  IF INSERTING THEN
    INSERT INTO t2 VALUES(:new.id);
  END IF;
  
  IF UPDATING THEN
    UPDATE t2
       SET id = :new.id
     WHERE id = :old.id;
  END IF;
  
  IF DELETING THEN
    DELETE FROM t2 WHERE id = :old.id;
  END IF;
  
END t1_trg;
/

Production DB

CREATE TABLE test_delete(id NUMBER);

BEGIN
INSERT INTO test_delete VALUES(100);
INSERT INTO test_delete VALUES(200);
INSERT INTO test_delete VALUES(300);
COMMIT;
END;
/

CREATE OR REPLACE TRIGGER prev_del_trg
BEFORE DELETE 
ON test_delete
BEGIN
  RAISE_APPLICATION_ERROR(-20002, 'Delete Operation not Possible');
END prev_del_trg;
/

CREATE TABLE citi_employees_tb 
AS 
SELECT employee_id, first_name, hire_date, salary, department_id
 FROM employees
WHERE department_id IN(10,20,60,90);

CREATE TABLE citi_audit_sal_hist_tb
( employee_id  NUMBER
, old_salary   NUMBER
, new_salary   NUMBER
, updated_by   VARCHAR2(30)
, updated_dttm TIMESTAMP
);

CREATE OR REPLACE TRIGGER audit_emp_sal_trg
AFTER UPDATE OF salary ON citi_employees_tb
FOR EACH ROW
BEGIN

  SELECT salary INTO v_salary FROM citi_employees_tb 
   WHERE employee_id = :OLD.employee_id;

  INSERT INTO citi_audit_sal_hist_tb(employee_id, old_salary, new_salary, updated_by, updated_dttm)
                              VALUES(:OLD.employee_id, :OLD.salary, :NEW.salary, USER, SYSTIMESTAMP);
END audit_emp_sal_trg;
/

CREATE OR REPLACE TRIGGER data_access_trg
BEFORE INSERT OR UPDATE OR DELETE
ON citi_employees_tb
BEGIN
  
  IF TO_CHAR(SYSDATE,'D') IN (1,7) OR  
     TO_CHAR(SYSDATE,'HH24:MI') NOT BETWEEN '09:00' AND '17:00' 
  THEN
    RAISE_APPLICATION_ERROR(-20005, 'TN Not Possible in Non Buiness Hrs/ Days');
  END IF;
END;
/

Max no of Triggers on Particular Table : 12

-- How to DISABLE Trigger?
-- How to Enable Trigger?

ALTER TRIGGER t1_trg DISABLE;
ALTER TRIGGER t1_trg ENABLE;

-- How to Disable all the triggers related to Particular table ?

ALTER TABLE table_name DISABLE ALL TRIGGERS;

#3

  10      5000      250000
  20      10000     500000
  30      35000     1700000
  
  
CREATE OR REPLACE TRIGGER sal_update_rest_trg
BEFORE INSERT OR UPADTE
ON EMPLOYEES
DECLARE
  v_minsal    NUMBER;
  v_max_sal   NUMBER;
  v_jobid     VARCHAR2(30);
BEGIN
  
  SELECT jobid INTO v_jobid FROM employees WHERE employee_id = :old.employee_id;


  IF :new_salary NOT BETWEEN v_minsal AND v_max_sal THEN
    RAISE_APPLICATION_ERROR(-20200,'Salary Not IN Limit');
  END IF;

END sal_update_rest_trg;
/ 

-- How to COMMIT inside the Trigger 
-- Yes by using PRAGMA Autonomous Trigger 


  t1       t2    PRAGMA autonomous_transaction
  ------   -----------
  1         1    COMMIT
  2         2    COMMIT
  3         3    COMMIT
  ROLLBACK;
  
-- Mutating Error 

12c FOLLOWS 

INSTEAD OF 
DML on Complex View 


CREATE OR REPLACE TRIGGER bkp_emp_insert_trg
INSTEAD OF INSERT ON employees
BEGIN
  INSERT INTO bkp_employees(c1,c2,c3,c4) 
   VALUES(:new.c1, :new.c2, :new.c3, :new.c4);
END bkp_emp_insert_trg;
/

CREATE OR REPLACE TRIGGER bkp_emp_insert_trg
INSTEAD OF INSERT ON epdep_vw
BEGIN
  INSERT INTO employees(c1,c2,c3,c4) 
   VALUES(:new.c1, :new.c2, :new.c3, :new.c4);
   
  INSERT INTO departments(c5,c6,c7) 
   VALUES(:new.c5, :new.c6, :new.c7);
   
END bkp_emp_insert_trg;
/

LOGON LOGOFF TRIGGER