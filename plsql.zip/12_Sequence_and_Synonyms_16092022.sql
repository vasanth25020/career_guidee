Sequence  (_seq)
		Numeric Value Generator
		It is a Schema Object  | Sharable Object
		Mostly used to generate PRIMARY KEY value 
		Max Value of Sequence : 99999...999 (27)
		
		INC | SR |ODR |REF 
		
		sequence related psuedocolumns
		
		    NEXTVAL
			CURRVAL
		
		Data Dict Table   :  user_sequences
		
CREATE SEQUENCE sid_seq
START WITH 1
MINVALUE 1
MAXVALUE 10
INCREMENT BY 1
NOCYCLE
NOCACHE;

CREATE SEQUENCE sid2_seq;

CREATE TABLE cse_tb(id NUMBER, name VARCHAR2(20));
CREATE TABLE eee_tb(id NUMBER, name VARCHAR2(20));

INSERT INTO cse_tb VALUES(sid_squ.NEXTVAL, 'Saravanan');  -->--1
INSERT INTO cse_tb VALUES(sid_squ.NEXTVAL, 'Kamal');      -->--2
INSERT INTO cse_tb VALUES(sid_squ.NEXTVAL, 'Tamil');      -->--3
SELECT*FROM cse_tb;                                       

SELECT sid_seq.CURRVAL FROM dual;
SELECT sid_seq.NEXTVAL FROM dual;                         -->--4

INSERT INTO sec_tb  VALUES(sid_seq.NEXTVAL, 'Jeni');      -->--5
INSERT INTO sec_tb  VALUES(sid_seq.NEXTVAL, 'John');      -->--6 7 8 9 10

ORA-08004: sequence SID_SEQ.NEXTVAL exceeds MAXVALUE and cannot be instantiated

ALTER SEQUENCE sid_seq
MAXVALUE 15;

DROP SEQUENCE sid_seq;

NOCYCLE  | CYCLE
NOCACHE  | CACHE 20

SELECT * FROM user_sequences;

why the gap in sequence?

    Same Sequence is used in some other table
	ROLLBACK
	Memory related Issue
	
	100
	101
	
	200
	100              962437294696   3292392347
	
	465     DL
	465     DP
	
	INC1609202222465   DL
	INC1709202222465   DP
	
CREATE SEQUENCE test_seq
START WITH 251
INCREMENT BY 1
MAXVALUE 99999;

SELECT 'INC'
   ||TO_CHAR(SYSDATE,'DDMMYYYY')
   ||LPAD(test_seq.NEXTVAL,5, 0)inc_number
 FROM dual;


--11g Version

DECLARE
    v_ref_id VARCHAR2(30) := test_seq.NEXTVAL;
BEGIN
END;
/

--12g 
   CREATE TABLE test_tb(id NUMBER DEFAULT seq_name.NEXTVAL);
   
   
--Synonyms 

   Used to provide alternate name to any object 
	
	--types of synonyms
	Private Synonym (Default)
	Public Synonym
	
CREATE SYNONYM emp FOR employees;	
CREATE SYNONYM dept FOR departments;

SELECT * FROM emp;

--Public synonym 
CREATE PUBLIC SYNONYM loc FOR locations;

SELECT * FROM user_synonyms;

SELECT * FROM user_synonyms;
SELECT * FROM all_synonyms WHERE sysnonym_name = 'LOC';

SELECT * FROM all_objects WHERE object_name= 'LOC';


--citiDB
--HR

CREATE * FROM employees;
CREATE * FROM hr.employees;

--sr
CREATE * FROM hr.employees;

--HdfcDB

SELECT * FROM hr.employees@citiDB;

ENH_DB
tbs2_blltr_deal_main_txn_tb
citidb

SELECT ENH_DB.tps2_blltr_deal_main_txn_tb@citidb;

CREATE SYNONYM dmain
FORENH_DB.tps2_blltr_deal_main_txn_tb@citidb

SELECT * FROM dmain;


pending_loan_dtls          dummy_pending_loan_dtls

200                          200
                  
				             pld
							 
							 700+(pld)
							 

SELECT name FROM v$database;
SELECT * FROM v$version;

--Directory | DataPump | Mview | Table Partition 


CREATE DIRECTORY my_dir
AS 'D:Script';

SELECT * FROM all_directories;

--DataPump (expdp | impdp) table | Schema | Database 
Refer any website

--Mview / Snapshot 


  Materialized View Contains Data
          
		      View            Materialized View
			  
			  No              Yes
			  NOT possible    possible
			  
CREATE MATERIALIZED VIEW sal_mvw
REFRESH COMPLETE
NEXT SYSDATE+7
AS
SELECT * FROM sal_txn_tb WHERE dep_name='SAL';


REFRESH         COMPLETE / FAST (LOG)

EXEC dbms_mview.REFRESH('SAL_MVW','c');



