Stored Procedural (_sp)

		It is a named PLSQL sub program which compiled and stored in the database for repeated usage.
		It is a schema  object 
		Procedure perform and Action | mainly used to implement Business logics
		Procedure may or may not return any value 
		
		Parameter mode : IN         OUT             IN OUT
		Data Dictionary table : user_procedures  user_source  user_errors
		
		
DECLARE 
	v_a NUMBER :=100;
	v_b NUMBER :=90;
	v_c NUMBER;
BEGIN 
	v_c := v_b+v_a;
	dbms_output.put_line(v_c);
END;
/

CREATE OR REPLACE PROCEDURE add_sp 
AS      -- IS/AS

		v_a NUMBER :=100;
		v_b NUMBER :=90;
		v_c NUMBER;
BEGIN 
 
		v_c := v_a + v_b;
		dbms_output.put_line(v_c);             --- REFERENCE

END;
/

#1
EXECUTE add_sp

#2
BEGIN
add_sp;
END;
/

#3
RPC: Remote Procedure Call

CREATE OR REPLACE PROCEDURE add_sp(p_a IN NUMBER,p_b NUMBER)
AS
	v_c NUMBER;
BEGIN
	v_c := p_a + p_b;
	dbms_output.put_line(v_c);
END add_sp;
/

SHOW err | SHOW error

SELECT text FROM user_errors WHERE name = 'add_sp';

--Passing is equal to declaration 
--Default IN MODE
--IN mode parameter are read only 
--No need to mentiion size in datatype


IN            -- call by reference 
OUT INOUT     -- call by value 

EXEC add_sp(90,234);

DECLARE 
	-- Front end screen
	v_a NUMBER :=90;
	v_b NUMBER :=234;
BEGIN
	add_sp(v_a,v_b);
END add_sp;
/

CREATE OR REPLACE PROCEDURE add_sp(p_a IN NUMBER,p_b NUMBER,p_c OUT NUMBER)
AS
BEGIN
	p_c :=p_a + p_b;
END add_sp;
/

VARIABLE r NUMBER;
EXEC add_sp(90,256,:r);         --   print r;


DECLARE
	v_a NUMBER :=1000;
	v_b NUMBER :=9000;
	v_c NUMBER;
BEGIN
	add_sp(v_a,v_b,v_c);
	dbms_output.put_line('RESULT :'||v_c);
END add_sp;
/

7879708485        (787)970-8485

CREATE OR REPLACE PROCEDURE phone_format_sp(ph_no IN OUT VARCHAR2)
AS
BEGIN 
	ph_no := '('||substr(ph_no,1,3)||
			 ')'||substr(ph_no,4,3)||
             '-'||substr(ph_no,7);
END phone_format_sp;
/

DECLARE 
	v_no VARCHAR2(30) :=7094190671;
BEGIN 
	phone_format_sp(v_no);
	dbms_output.put_line('NEW PHONE FORMAT :'||v_no);
END phone_format_sp;
/

add_sp(p_a IN NUMBER, p_b IN NUMBER);
add_sp(p_a IN NUMBER, p_b IN NUMBER,p_c IN NUMBER);

Procedure Overloading 

add_sp(p_a IN NUMBER, p_b IN NUMBER,p_c IN NUMBER);

add_sp(10,20,30)                                           -- unnamed notation
add_sp(p_a => 10, p_b => 20, p_c => 30);                   -- named notation 
add_sp(       10, p_b => 20, p_c => 30);                   -- mixed notation 
add_sp(       10, p_b => 20,        30);                   -- Error


--Local Procedure 

DECLARE 
	PROCEDURE p1
	AS
	BEGIN 
		dbms_output.put_line('IN local Procedure p1');
	END;
BEGIN
	dbms_output.put_line('IN Procedure');
	p1;
	dbms_output.put_line('IN Procedure');
	p1;
END;
/

DESC phone_format_sp;

DROP PROCEDURE proc_name;

ALTER PROCEDURE proc_name COMPILE;


STORED FUNCTION(_fn)

		It is a named PLSQL sub program which compiled and stored in the database 
		It is a schema object
		Function compute value / simple Fetch
        Function contains RETURN clause 

Parameter mode : IN               OUT                   IN OUT
Data Dictionary table: user_function     user_source     user_errors


CREATE OR REPLACE FUNCTION add_fn(p_a IN NUMBER, p_b IN NUMBER)
RETURN NUMBER
AS 
	v_c NUMBER;
BEGIN 
	V_C :=p_a+p_b;
	RETURN v_c;
END add_fn;
/

SELECT add_fn(10,20) FROM dual;

SELECT employee_id, salary, add_fn(employee_id,salary) 
FROM employees 
WHERE department_id IN(10,60,90);

DECLARE 
BEGIN
	v_result := add_fn(10,60,90);
END;
/

--It is posible to return more than one value in function 
 
 OUT PARAMETER | we cant call this function in sql 
 Collection 
 REFCURSOR
 
--What will possible to call procedure | DML operation in FUNCTION

	PRAGMA autonomous_transaction
	
CREATE OR REPLACE FUNCTION emp_ck_fn(p_employee_id IN NUMBER)
RETURN BOOLEAN
AS
v_count NUMBER;
BEGIN 
	SELECT count(*) INTO v_count
	FROM employees 
	WHERE employee_id=p_employee_id;
	
	IF v_count =1 THEN
		RETURN TRUE;
	ELSE
		RETURN FALSE;
	END IF;
END;
/

BEGIN
	IF emp_ck_fn(100) THEN
		dbms_output.put_line('valid employee_id');
	ELSE 
		dbms_output.put_line('Invalid employee_id');
	END IF;
END;
/

PRAGMA autonomous_transaction | independ session 

CREATE TABLE test_insert(id NUMBER PRIMARY KEY)
BEGIN
	INSERT INTO test_insert VALUES(10);
	INSERT INTO test_insert VALUES(20);
	INSERT INTO test_insert VALUES(30);
	insert_sp;
	INSERT INTO test_insert VALUES(40);
	ROLLBACK;
END;
/

CREATE OR REPLACE PROCEDURE insert_sp
AS
	PRAGMA autonomous_transaction;
BEGIN
	INSERT INTO test_insert VALUES(100);
	INSERT INTO test_insert VALUES(200);
	INSERT INTO test_insert VALUES(300);
	COMMIT;
END insert_sp;
/

























