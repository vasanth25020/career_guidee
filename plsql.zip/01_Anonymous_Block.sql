---PLSQL

--It is a Procedural Language is extence to sql.
--Here We are going to group set of SQL and PLSQL into single block and sent to the server for execution in single go. 
--It will Reduce Network Traffic 


PLSQL TOPICS:

       1. ANONYMOUS BLOCK
       2. CONTROL STATMENTS 
       3. CURSOR 
       4. EXCEPTION 
       
       5. STORED PROCEDURE 
       6. STORED FUNCTION  
       
       7. PACKAGE 
       
       8. TRIGGER

	   

DECLARE   --Optional 
    --Variable 
	--Cursor 
	--Exception 
	--Sub program

BEGIN   --Mandatory 
    --SQL and PLSQL statement 
	--Application and Business Logics 
	
EXCEPTION  --Optional 
    --Error Handling 
	
END;   --Mandatory
/

Anonymous block is an unnamed block
it is not complied and stored in the database 
one time only procedure 

BEGIN 
  NULL;
 END;
 /
 
 BEGIN 
   dbms_output.put_line ('Welcome to Infycle');
  END;
  /
  
  SET SERVEROUTPUT ON 
  

--Variable 
     Types 
       1. PLSQL Variable 
           Scalar 
           Composite --Collection 
           Reference --REFCURSOR 
           Large Object
		   
       2. NON PLSQL variable 
       	   Bind Variable /host Variable 
	 
Per Line we can declare only one Variable 1-30 
Character long (loaded-dttm) ref-id | info_cng_num)
Assignment operator  | a:=10 
Standard v_ | p_ | lv_ | c_

DECLARE 

   v_a  NUMBER  :=120;
   v_b  NUMBER  :=230;
   v_c  NUMBER 

BEGIN 
   v_c  := v_a   +v_b;
   dbms_output.put_line(v_a || '+' || v_b || '=' || v_C);
END;
/

DECLARE 

v_a           NUMBER :=10;
v_b           NUMBER :=20;
v_name        VARCHAR2(30)          :=INITCAP ('rahul vignesh');
v_todaydt     DATE                  :=SYSDATE;
v_dob         DATE                  :=TO_CHAR (15-08-99,'DD-MM-YY');
v_c           NUMBER                :=NULL;
v_depid       NUMBER  DEFAULT 90;
v_nnck        NUMBER  NOT NULL      :=190;
v_pi          CONSTANT NUMBER       :=3.14;
v_ck1         VARCHAR(30)           :='';
v_ck2         VARCHAR(30);

BEGIN 
   v_b :=300;
    --v_pi :=3.45;

 dbms_output.put_line ('v_a           :='||v_a);
 dbms_output.put_line ('v_b           :='||v_b);
 dbms_output.put_line ('name          :='||v_name);
 dbms_output.put_line ('today''s Date :='||v_todaydt);
 dbms_output.put_line ('DOB           :='||v_dob);
 dbms_output.put_line ('DOB fmt 2     :='||TO_CHAR(v_dob,'DDth "of" month,YY'));
 dbms_output.put_line ('DID           :='||v_depid);
 dbms_output.put_line ('PI VALUE      :='v_pi);
 dbms_output.put_line ('Check 01      :='NVL(v_ck1),0));
 dbms_output.put_line ('Check 02      :='NVL(v_ck2),0));
  END;
  /
  
  <<ot>>
 DECLARE 
   v_a NUMBER :=10;
   v_c NUMBER :=50;
 BEGIN 
  <<inb>>
  DECLARE 
   v_a NUMBER :=20;
   v_d NUMBER :=100;
   
  BEGIN  
    dbms_output.put_line(v_a);     -->--20
	dbms_output.put_line(ot.v_a);  -->--10
	dbms_output.put_line(v_c);     -->--50
END;
    dbms_output.put_line(v_a);
	dbms_output.put_line(v_d);
/

DECLARE 
  v_max_sal  NUMBER;
BEGIN 
   SELECT MAX(salary)
    INTO v_max_sal 
    FROM employees;
   dbms_output.put_line('maximum salary:='||v_max_sal);
  END;
/
  
DECLARE 
  v_employee_id       NUMBER;
  v_first_name        VARCHAR2(30);
  v_hire_date         DATE;
  v_salary            NUMBER;
  v_department_id     NUMBER;
BEGIN 
  SELECT employee_id,first_name,hire_date,salary,department_id
   INTO v_employee_id,v_first_name,v_hire_date,v_salary,v_department_id
   FROM employees 
  WHERE employee_id =100;
  --WHERE department_id=90;
  dbms_output.put_line(LPAD('-',50,'-'));
  dbms_output.put_line('employee_id  :'|| v_employee_id);
  dbms_output.put_line('first_name   :'|| v_first_name);
  dbms_output.put_line('hire_date    :'|| v_hire_date);
  dbms_output.put_line('salary       :'|| v_salary);
  dbms_output.put_line('department_id:'||v_department_id);
  dbms_output.put_line(LPAD('-',50,'-'));
  END;
/

DECLARE 
 v_department_id  NUMBER  :=10;
 v_department_name departments.department_name%TYPE;
 
BEGIN 
  SELECT department_name 
   INTO v_department_name 
   FROM departments 
  WHERE depart_id=v_department_id 
  
  dbms_output.put_line('department_id:'||v_department_id);
 END;
 /
 
 DECLARE 
    v_employee_id   employees.employee_id%TYPE;	
    v_first_name    employees.first_name%TYPE; 
    v_hire_date     employees.hire_date%TYPE;
    v_salary        employees.salary%TYPE;
    v_department_id employees.department_id%TYPE;
	
BEGIN 
  SELECT employee_id,first_name,hire_date,salary,department_id
   INTO v_employee_id,v_first_name,v_hire_date,v_salary,v_department_id
   FROM employees 
  WHERE employee_id =100;
--WHERE department_id=90;
  dbms_output.put_line(LPAD('-',50,'-'));
  dbms_output.put_line('employee_id  :'|| v_employee_id);
  dbms_output.put_line('first_name   :'|| v_first_name);
  dbms_output.put_line('hire_date    :'|| v_hire_date);
  dbms_output.put_line('salary       :'|| v_salary);
  dbms_output.put_line('department_id:'||v_department_id);
  dbms_output.put_line(LPAD('-',50,'-'));
END;
/

DECLARE 
 v_alldata   employees&ROWTYPE;
 BEGIN 
   SELECT * 
    INTO v_alldata
    FROM employees 
   WHERE employee_id=100;
  --WHERE employee_id=90;
  dbms_output.put_line(LPAD('-',50,'-'));
  dbms_output.put_line('employee_id  :'|| v_alldata.employee_id);
  dbms_output.put_line('first_name   :'|| v_alldata.first_name);
  dbms_output.put_line('hire_date    :'|| v_alldata.hire_date);
  dbms_output.put_line('salary       :'|| v_alldata.salary);
  dbms_output.put_line('department_id:'||v_alldata.department_id);
  dbms_output.put_line(LPAD('-',50,'-'));
  END;
  /
  
--Bind Variable /Host Variable 
    VARIABLE a NUMBER;

BEGIN 
 SELECT MAX(salary) INTO :a FROM employees;
 END;
 /
 
 PRINT a 
 SELECT :a FROM dual;
 
 SQL>VARIABLE b NUMBER;
 SQL>EXEC  :b :=600;
 
 DECLARE 
   v_department_id   NUMBER:=90;
   
  BEGIN 
   DELETE FROM tdepartments WHERE department_id=v_department_id;
   COMMIT;
   END;
   /
   
   #1
   /
   
   #2
   BEGIN 
     --INSERT 
	 --UPDATE 
	 --DELETE 
     COMMIT;
END;
/

CREATE TABLE t1 (id NUMBER);

BEGIN 
 INSERT INTO t1(id) VALUES(10);
 INSERT INTO t1(id) VALUES(20);
 INSERT INTO t1(id) VALUES(30);
 INSERT INTO t1(id) VALUES(40);
 INSERT INTO t1(id) VALUES(50);
 COMMIT;
END;
/

ALTER TABLE t1 ADD CONSTRANT t1_id_pk PRIMARY KEY (id);

BEGIN 
  --implicit savepoint 
  --DDL/DCL
  --Dynamic SQL 
 EXECUTE IMMEDIATE 'TRUNCATE TABLE t1';
 INSERT INTO t1(id) VALUES(10);
 INSERT INTO t1(id) VALUES(20);
 INSERT INTO t1(id) VALUES(30);
 INSERT INTO t1(id) VALUES(30);
 INSERT INTO t1(id) VALUES(50);
 COMMIT;
END;
/

 