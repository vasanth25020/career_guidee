CURSOR (_C)

		It is a private work area where the query get passed and executed 
		Activeset 
		
	Implicit Cursor 
		
		If your query return exactly one Row | DML
		NO need to declare it Implicitly declared by PLSQL Engine
		NAME : SQL
	
	Explicit Cursor 
	
		We need to declare and name it 
		
	Cursor Attributes 
	
		%FOUND %NOTFOUND %ISOPEN %ROWCOUNT
		
DECLARE 
	
	v_employee_id   employees.employee_id %TYPE;
	v_first_name    employees.first_name%TYPE;
	v_hire_date     employees.hire_date%TYPE;
	v_salary        employees.salary%TYPE;
	v_department_id employees.department_id%TYPE;
	v_count         NUMBER :=0;
	
	CURSOR emp_c
	IS 
	SELECT employee_id, first_name, hire_date, salary, department_id 
	FROM employees
	WHERE department_id=90;
	
	--v_alldata emp_c%ROWTYPE;
	
BEGIN

	dbms_output.put_line('-------------------------------------');
	
	OPEN emp_c;
	LOOP
		FETCH emp_c
			INTO v_employee_id, v_first_name, v_hire_date, v_salary, v_department_id;
			
			EXIT WHEN emp_c%NOTFOUND;
			
			dbms_output.put_line('%'||emp_c%ROWCOUNT);
			dbms_output.put_line('Emp_id    :'||v_employee_id);
			dbms_output.put_line('Name      :'||v_first_name);
			dbms_output.put_line('Hire_Date :'||v_hire_date);
			dbms_output.put_line('Salary    :'||v_salary);
			dbms_output.put_line('Dept_id   :'||v_department_id);
			dbms_output.put_line('-------------------------------------------');
			
			v_count := v_count + 1;
			
			--EXIT WHEN emp_c%FOUND;
	END LOOP;
	CLOSE emp_c;
	
	dbms_output.put_line('TOtal No of Records :'||v_COUNT);
	
	IF emp_c%ISOPEN THEN 
	CLOSE emp_c;
	
		dbms_output.put_line('Cursor Closed');
		
	ELSE 
	
		dbms_output.put_line('Cursor Already Closed');
		
	END IF;
END;
/

DECLARE 

	CURSOR emp_c 
	IS 
	SELECT employee_id, first_name, hire_date, salary, department_id
	FROM employees
	WHERE department_id=90;
	
BEGIN 

	dbms_output.put_line('-----------------------------------------');
	
	--Cursor FOR LOOP
	
	FOR i IN emp_c 
	LOOP
			
			dbms_output.put_line('Emp_id    :'||i.employee_id);
			dbms_output.put_line('Name      :'||i.first_name);
			dbms_output.put_line('Hire_Date :'||i.hire_date);
			dbms_output.put_line('Salary    :'||i.salary);
			dbms_output.put_line('Dept_id   :'||i.department_id);
	END LOOP;
	
	FOR j IN(SELECT department_id, department_name FROM departments WHERE department_id IN(10,20,30))
	
	LOOP
		dbms_output.put_line(j.department_id||'-'|| j.department_name);
		
	END LOOP;
END;
/ 

CREATE TABLE dept3 AS SELECT * FROM departments;

BEGIN 

UPDATE dept3
	SET department_name=UPPER(department_name)
WHERE department_id IN(10,20,30);

dbms_output.put_line(SQL%ROWCOUNT ||'ROW(S) UPDATED');
COMMIT;
END;
/

BEGIN 
	
	DELETE FROM dept3 WHERE department_id IN(10,20,30,40,50);
	dbms_output.put_line(SQL%ROWCOUNT||'ROW(S) DELETED');
	COMMIT;
END;
/

CREATE TABLE test_insert(id NUMBER);
BEGIN
	INSERT INTO test_insert VALUES(10);
	INSERT INTO test_insert VALUES(20);
	INSERT INTO test_insert VALUES(30);
	INSERT INTO test_insert VALUES(40);
	INSERT INTO test_insert VALUES(50);
	dbms_output.put_line(SQL%ROWCOUNT||'ROW(S) INSERTED');
	COMMIT;
END;
/

BEGIN
	INSERT INTO dept3(SELECT * FROM departments WHERE department_id IN(10,20,30,40,50));
	dbms_output.put_line(SQL%ROWCOUNT||'ROW(S) INSERTED');
	COMMIT;
END;
/

BEGIN
	DELETE FROM dept3 WHERE department_id IN(1,2,3,4,5);
	
	IF SQL%FOUND THEN
		dbms_output.put_line(SQL%ROWCOUNT||'ROW(S DELETED');
	END IF;
	
	IF SQL%NOTFOUND THEN
		dbms_output.put_line('NO ROW(S) DELETED');
	END IF;
	COMMIT;
END;
/

DECLARE 
	
	CURSOR emp_c
	IS 
	SELECT rowid, employee_id, first_name, hire_date, salary, department_id
	FROM employees_tb
	FOR UPDATE OF salary NOWAIT;  --LOCK
	
BEGIN

	FOR i IN emp_c 
	LOOP
		IF i exep >10 THEN
		UPDATE emp_tb
			SET salary = salary*2
		WHERE CURRENT of emp_c;
		
		--where rowid =i.rowid;
		--where emp_id=i.emp_id;
	
		END IF;
	END LOOP;
	COMMIT;
END;
/

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	














