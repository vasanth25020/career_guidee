Control Statements | condition and looping


        IF
        IF EKSE
        Multiple IF ELSE
		
		LOOP
		for LOOP
		WHILE LOOP
		
		CASE
		EXIT | EXIT WHEN | RETURN | CONTINEU(11g)

        GOTO

DECLARE
    v_a NUMBER :=10;
BEGIN
    dbms_output.put_line('value of v_a is 10');
END;
/		

DECLARE
    v_a NUMBER :=20;
BEGIN
  IF v_a=10 THEN
    dbms_output.put_line('value of v_a is 10');
END;
/		

DECLARE
    v_a NUMBER :=20;
BEGIN
  IF v_a=10 THEN
    dbms_output.put_line('value of v_a is 10');
  ELSE
    dbms_output.put_line('value of i is not 10');  
  EMD IF;	
END;
/		

DECLARE
	v_a NUMBER :=40; 
BEGIN
	IF v_a=10 THEN
		dbms_output.put_line('value of v_a is 10');
	ELSEIF v_a=20 THEN
		dbms_output.put_line('value of v_a is 20');
	ELSEIF v_a=30 THEN
		dbms_output.put_line('value of v_a is 30');
    ELSEIF v_a=40 THEN
		dbms_output.put_line('value of v_a is 40');
	ELSEIF v_a=50 THEN
		dbms_output.put_line('value of v_a is 50');
	ELSE
		dbms_output.put_line('value of i is not in 10,20,30,40 and 50');
	END IF;
END;
/


-->--LOOP

DECLARE
	v_a NUMBER:=1;
BEGIN
	LOOP
		dbms_output.put_line('value of i is'||v_i);
		/* IF v_i=10 THEN
			EXIT
		END IF;*/
		
		EXIT WHEN v_i=10;
		v_i:=v_i+1;
	END LOOP;
END;
/

--FOR LOOP

BEGIN
	FOR i IN 1..10
	LOOP
		dbms_output.put_line('value of i is'||i);
	END LOOP
END;
/

BEGIN
	DOR i IN REVERSE 1..10
	LOOP
		dbms_output.put_line('value of i is'||i);
	END LOOP;
END;
/

PLS-00201:Identifier 'I' must be declare

DECLARE
	v_i NUMBER :=1;
BEGIN
	WHILE(v_i<=10)
	LOOP
		dbms_output.put_line(v_i);
		v_i :=v_i+1;
	END LOOP;
END;
/

2 4 6...50
5 10 15..50
1 2 3 4 6 7 8 9 11 12 13 14 16..49

DECLARE
	v_did NUMBER:=30;
BEGIN
	CASE
		WHEN v_did=10 THEN
			dbms_output.put_line('slot_01');
		WHEN v_did=20 THEN 
			dbms_output.put_line('slot_02');
		WHEN v_did=30 THEN
			dbms_output.put_line('slot_03');
		ELSE
			dbms_output.put_line('slot_04');
	END CASE	
END;
/

EXIT / EXIT WHEN ...come out from the current LOOP

BEGIN
	<<m1>>
	LOOP
		LOOP
			EXIT m1 WHEN...
		END LOOP;
		
		EXIT WHEN...
	END LOOP
END;
/


CONTINUE

DECLARE
	v_i NUMBER:=1;
BEGIN
	LOOP
		dbms_output.put_line(v_i);
		v_i:=v_i+1;
		IF v_i=5 THEN
			EXIT;
		END WHEN v_i>50;	
	END LOOP;
END;
/

DECLARE
	v_i NUMBER:=1;
BEGIN
	LOOP
		dbms_output.put_line(v_i);
		v_i:=v_i+1;
		IF v_i=5 THEN
			CONTINUE;
		END IF;
		
		EXIT WHEN v_i>50;	
	END LOOP;
END;
/

BEGIN
GOTO header_message;

<<greeting_message>>
DBMS_OUTPUT.PUT_LINE('Hi');

GOTO eading_message;

<<header_message>>
DBMS_OUTPUT.PUT_LINE('Demonstration of working of PL/SQL GOTO statement')
GOTO greeting_message

<<ending_message>>
DBMS_OUTPUT.PUT_LINE('wish you all the best for your learning...');
END;
/

*
**
***
****
*****

DECLARE
	v_no NUMBER:=1;
BEGIN
	FOR i IN 1..5 LOOP
		FOR j IN 1..i LOOP
			dbms_output.put_line(v_no);
			v_no:=v_no+1;
		END LOOP;
		dbms_output.put_line('');
	END LOOP;
END;
/











































