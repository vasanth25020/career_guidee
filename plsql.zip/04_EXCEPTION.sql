 EXCEPTION      -- Error Handing

Types of Exception

		Pre_Defined Exception 
			
			Zero_divide 
			no_data_found
			too_many_rows 
			dup_val_on_index
			value_error 
			invalid_cursor 
			cursor_already_open
			--CASE_NOT_FOUND
			+3
			OTHERS(100%|must handled at least)
			  SQLERRM | SQLCODE
	 		  
		
		User Defined Exception 
		Application Error -- As per the frond end developer request
		PRAGMA Exception_inif -- Used to name unnamed Exception 
		
	- 0 to -19999 : Oracle Error Range 
	-20000 to -20999 : User Error Range 
	
-Scope 
 Error 
 How to Trap Exception?
 
		EXCEPTION 
			WHEN exception_name THEN 
				...
				
 How will you pass error message front end developer?
 
		OUT Parameter 
		
	Error lolg Table 
	

DECLARE 

	v_a   VARCHAR2(30);
	v_b   NUMBER(3) :=900;
	
BEGIN
	v_b   :=6000;
	
	--SELECT 5/0 INTO v_a FROM dual;
	--SELECT first_name INTO v_a FROM employees WHERE employee_id = 6;
	--SELECT first_name INTO v_a FROM employees WHERE department_id = 90;
	
	dbms_output.put_line(v_a);
	dbms_output.put_line(v_b);
EXCEPTION 
	
			
		WHEN Zero_divide THEN
			dbms_output.put_line('Enter some other number');
		WHEN no_data_found THEN	
			dbms_output.put_line('Enter valid employee_id');
		WHEN too_many_rows THEN	
			dbms_output.put_line('Declare cursor of fetch more than one rec');
		WHEN dup_val_on_index THEN	
			dbms_output.put_line('value already Available');
		WHEN value_error THEN
			dbms_output.put_line('check size of the variable');
		WHEN OTHERS THEN
			dbms_output.put_line('some otherr Error ~'|| SQLERRM||'~'SQLCODE);
END;
/

DECLARE 

	v_gender  VARCHAR2(30) :='S'
	gender_ex EXCEPTION;
	
BEGIN 

	IF UPPER(v_gender) NOT IN('M','F') THEN 
		RAISE gender_ex;
	END IF;
	
	dbms_output.put_line('genter :'|| v_gender);
EXCEPTION

	WHEN genter_ex THEN	
		dbms_output.put_line('genter must be M/F');
END;
/

DECLARE
	v_gender   VARCHAR2(30) :='S'
BEGIN
	IF UPPER(v_gender) NOT IN('M','F') THEN
		RASIE_APPLICATION_ERROR(-20001,'INVALID GENTER');
	END IF;
	dbms_output.put_line('genter :'||v_gender);
END;
/

CREATE TABLE test_insert(id NUMBER NOT NULL)
			
			
	INSERT INTO test_insert VALUES(10);
	INSERT INTO test_insert VALUES(20);
	
	ERROR at line 1;
	
	ORA -01400 : cannot insert NULL into ("HR","TEST_INSERT","ID")
	
	
DECLARE 

		nn_ex    EXCEPTION 
		PRAGMA   EXCEPTION_INIT(nn_ex,-01400);
BEGIN 
	INSERT INTO test_insert VALUES(NULL);
	COMMIT;

	EXCEPTION 
		WHEN nn_ex THEN 
			dbms_output.put_line('NULL NOT allowed');

END;
/

err_log_tb  
    err_id      err_eq.NEXTVAL
    err_msg		SQLERRM
    err_cd 		SQLCODE
    module		
    pgm.name
    err.by      USER
   hap.dttm		SYSTIMESTAMP

dept   dummy_dept(27)pk

		delete all records from dummy_dept 
		loaddata from dept -> dummy_dept
		
		IF SQL%ROWCOUNT =0 THEN
		
		END IF;
		
		NO rows inserted
		
		
			
			
			
			
			
			