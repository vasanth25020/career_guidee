--Package (_pkg)

		Named sub program | compiled and stored in DATABASE
		Here are going to group logical sub program single units of code 
		(It is reduce network traffic)
		If execute any sub program inside the package rest of the program will also loaded(user memory) into the memory
		Will executing the next sub program it will take less time of exection 
		We can declare gobal variable cursor and exception

Part of Package 
		
	    package	Specification (SPEC)
		package BODY
		
CREATE OR REPLACE PACKAGE calc_pkg 
AS
	PROCEDURE add_sp(p_a IN NUMBER, p_b IN NUMBER);
	PROCEDURE sub_sp(p_a IN NUMBER, p_b IN NUMBER);
	PROCEDURE multi_sp(p_a IN NUMBER, p_b IN NUMBER);
	FUNCTION sq_fn(p_a IN NUMBER) RETURN NUMBER;
	v_c NUMBER;
END;
/

CREATE OR REPLACE PACKAGE BODY calc_pkg
AS
PROCEDURE add_sp(p_a IN NUMBER, p_b IN NUMBER)
AS
BEGIN
v_c:=p_a+p_b;
dbms_output.put_line(v_c); 
END add_sp;
PROCEDURE sub_sp(p_a IN NUMBER, p_b IN NUMBER)
AS
BEGIN
v_c:=p_a-p_b;
dbms_output.put_line(v_c); 
END sub_sp;
PROCEDURE multi_sp(p_a IN NUMBER, p_b IN NUMBER) 
AS
BEGIN
v_c:=p_a*p_b;
dbms_output.put_line(v_c); 
END multi_sp;
FUNCTION sq_fn(p_a IN NUMBER) RETURN NUMBER 
AS
BEGIN
v_c:=p_a*p_a;
RETURN v_c; 
END sq_fn;
END;
/

DROP PACKAGE package_name;
DROP PACKAGE BODY package_name;

package overloading

Forward Declaration in PACKAGE

DECLARE 
	PROCEDURE p1
	AS
BEGIN 

END;
/

DECLARE
	PROCEDURE p2
	PROCEDURE p3
	
	PROCEDURE p1
	AS
	BEGIN
		dbms_output.put_line('inside p1');
		p2;
	END;
	
	PROCEDURE p2
	AS
	BEGIN
		dbms_output.put_line('inside p2');
		p3;
	END;	
	
	PROCEDURE p3
	AS
	BEGIN
		dbms_output.put_line('inside p3');
		p1;
	END;
	
	BEGIN
		p1;
	END;
	/
	
CREATE OR REPLACE PACKAGE value_pkg
AS
	v_m_t_km NUMBER :=0.897;
END value_pkg;
/

BEGIN
	dbms_output.put_line(5* value_pkg.v_m_t_km);
END;
/
