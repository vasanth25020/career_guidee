sub query
   query with in another query 
   include within()
   inner query | outer query   
   placed on the right side of the operator


sub query types
		--non correlated sub query
	single row sub query -->operator =,>,<,>=,<=,<>
	multiple row sub query --> operator IN ALL ANY
	scalar sub query (SELECT)
	inline view (FROM clause)
	cor-related sub query 
	
-- single row sub query
        If your sub query returns exactly one row
        operators : = > < >= <= <>

--who are all getting salary more than Neena's salary

    SELECT employee_id,first_name,hire_date,salary,dedpartment_id FROM employees
WHERE salary>(SELECT salary FROM employees WHERE first_name='Neena' ) 	

--who are all getting salary more than avg salary of the company
      SELECT employee_id,first_name,hire_date,salary,department_id
	  FROM employees
	  WHERE salary>(SELECT AVG(salary) FROM employees);
	  
	SELECT*FROM students_tb
	WHERE total=(SELECT MAX(total)FROM students_tb);
	
	
--maltiple row sub query
	If your sub query returns more than one row 
	operator: IN ANY ALL
	
	
	
--ORA-01427:single row subquery returns more than one row
SELECT employee_id,first_name,hire_date,salary,department_id,
FROM employees
WHERE salary IN(SELECT salary FROM employees WHERE first_name='Alexander');


SELECT employee_id,first_name,hire_date,salary,department_id,
FROM employees
WHERE salary >ALL (SELECT salary FROM employees WHERE first_name='Alexander');

SELECT employee_id,first_name,hire_date,salary,department_id,
FROM employees
WHERE salary > ANY (SELECT salary FROM employees WHERE first_name='Alexander');
 

 
	SELECT  --Scalar sub query
	FROM    --inline view
	WHERE 
	--GROUP BY
	HAVING 
	--ORDER BY
	
	
	
--> salarysub query (sub query in SELECT clause)
    SELECT department_id, COUNT(*)
	FROM employees
	WHERE department_id IN (10,20,30,40,50)
GROUP BY department_id
ORDER BY 1;

SELECT
   (SELECT COUNT(*)FROM employees WHERE department_id=10)"Administration"
   ,(SELECT COUNT(*)FROM employees WHERE department_id=20)"Marketing"
   ,(SELECT COUNT(*)FROM employees WHERE department_id=30)"Purchasing"
   ,(SELECT COUNT(*)FROM employees WHERE department_id=40)"Human Resources"
   ,(SELECT COUNT(*)FROM employees WHERE department_id=50)"Shipping"
  FROM dual;
  
  
 --#2
 SELECT*FROM sign_tb
    SELECT SIGN(id).SUM(id)
	    FROM sign_tb
	GROUP BY SIGN(id)
	
SELECT
(SELECT SUM(id) FROM sign_tb WHERE SIGN(id)=1)"POSITIVE"
(SELECT SUM(id) FROM sign_tb WHERE SIGN(id)=-1)"NEGATIVE"
FROM dual;

SELECT employee_id
      ,firdt_name
	  ,hire_date
	  ,salry
	  ,e.department_id 
	  ,d.department_name
	FROM employees e,departments dedpartment_id
WHERE e.department_id= d.department_id;

SELECT employee_id
      ,firdt_name
	  ,hire_date
	  ,salry
	  ,e.department_id 
	  ,(SELECT d.department_name
      FROM departments d WHERE department_id=e.department_id)department_name
FROM employees e;



--display department_name with no of employees working in it

--Inline view 
		Named sub query in FROM clause
		here we are going to select data from intermediate resultset
		
--display all the department which contains more on of employees
SELECT X.*
  FROM ( SELECT department_id,COUNT(*) dcnt FROM employee 
        GROUP BY department_id)X 
		,( SELECT MAX(SUM(salary))dmsum FROM employee 
        GROUP BY department_id)y 
 WHERE x.dsum=y.dmsumt;
 
 
--display all the department which is allocated with more amount of salary
    SELECT X.*
	FROM(SELECT department_id,SUM(salary)dsum FROM employees
	    GROUP BY department_id)X
		,(  SELECT MAX(SUM(salary))dmsum FROM employees 
		 GROUP BY department_id)y
	WHERE X.dsum=y.dmsum;
	
	
-- who are all working as a manager-> DISTINCT column_name

--who are all working as a manager-> privious qur-sub qur-ignore NULL in sq 
 
--display no of employees reporting to each manager -> dept wise cnt-manager_id


  
--Having cluase

SELECT department_id,ROUNT(AVG(salary))avg_sal
   FROM employees
GROUP BY department_id
   HAVING ROUND (AVG(salry))>(SELECT salary FROM employees WHERE first_name='Neena')
ORDER BY 1;

--cor-related sub query
    outer query will get executed first 
    we cant execute inner query alone
    for each row input will be different

--display who are all getting salary more than avg salary of the company
SELECT e.employee_id,e.first_name,e.hire_date,e.salary,e.department_id
FROM employees e
WHERE e.salary>(SELECT AVG(salary) FROM employees);

	
--display who are all getting salary more than avg salary of the 90
SELECT e.employee_id,e.first_name,e.hire_date,e.salary,e.department_id
FROM employees e
WHERE e.salary>(SELECT AVG(salary) FROM employees WHERE department_id=90);


--display who are all getting salary more than avg salary of than avg salary of theire department		
SELECT e.employee_id,e.first_name,e.hire_date,e.salary,e.department_id
FROM employees e
WHERE e.salary>(SELECT AVG (salary)
               FROM employees WHERE department_id=e.department_id);
	
--who are getting salary more than thire manager
SELECT e.employee_id,e.first_name,e.hire_date,e.salary,e.manager_id
FROM employees e
WHERE e.salary > ( SELECT salary
                  FROM employees WHERE department_id=e.manager_id);
				  
--who are all hired before their manager
SELECT e.employee_id,e.first_name,e.hire_date,e.salary,e.manager_id
FROM employees e
WHERE e.hire_date < (SELECT hire_date FROM employees WHERE employee_id=e.manager_id);


--multiple column sub query
SELECT employee_id,first_name,hire_date,salary,department_id,manager_id
FROM employees 
WHERE department_id=(SELECT department_id FROM employees WHERE first_name='Neena')
AND manager_id=(SELECT manager_id FROM employees WHERE first_name='Neena')
AND first_name<>'Neena';

SELECT employee_id,first_name,hire_date,salary,department_id,manager_id
FROM employees
WHERE (department_id,manager_id)=(SELECT department_id,manager_id FROM employees WHERE first_name='Neena')
AND first_name<>'Neena';



--IN and EXISTS
SELECT * FROM employees
  WHERE employee_id IN(SELECT employee_id FROM employees WHERE department_id=90);
  SELECT*FROM employees
   WHERE EXISTS(SELECT 1 FROM employees WHERE department_id=270);
  IN <EXISTS>NOT EXISTS
  
  





 
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
   
	
	
	
	
	
	
	
	
	
	
	
	