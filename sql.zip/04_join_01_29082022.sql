
   JOIN
       selecting date from multiple tables

TYPES OF JOIN
         
		 Equi Join          --> matched records
		 outer join         -->matched+unmatched records
		     Right outer join 
			 left outer join
			 full outer join
		self join
		cross join
		natural join
		
    student_tb s            course_tb c           s.c_id=c.c_id

   s_name      c_id         c_id     c_name 
-------------------      --------------------
  Name_01      40            10      Oracle
  Name_02      20            20      Java
  Name_03      10            30      Bigdata
  Name_04      30            40      Python
  Name_05      60            50      Unix
-------------------     ---------------------


            Equi join                                       outer join

                                         ROJ                   LOJ                   FOJ

		s.c_id=c.c_id               s.c_id(+)c.c_id        s.c_id=c.c_id(+)          TBD
													    
 s_name      c_name                 s_name   c_name        s_name   c_name        s_name   c_name
 c_name                                                                        
 ----------------------          --------------------    -------------------    -------------------

name_01      python             name_01      python        name_01   python       name_01  python
name_02      java               name_02      java          name_02   java         name_02   java 
name_03      oracle             name_03      oracle        name_03   oracle       name_03   oracle 
name_04      big data           name_04      bigdata       name_04   bigdata      name_04    big data
                                   -           unix          name_05     -             -        unix    

----------------------       -------------------------    --------------------  ----------------------

--Equi join (matched records from both table)

SELECT employees.employee_id
       ,employee.first_name
       ,employee.hire_date
       ,employee.salary
       ,employee.department_id
	   ,departments.department_name
FROM employees e, departments d 
WHERE employees.department_id=department.department_id;


SELECT e.employee_id
      ,e.first_name 
      ,e.hire_name
      ,e.salary
	  ,e.department_id 
	  ,d.department_name
FROM employees e,departments d
WHERE e.department_id=d.department_id;



--outer join (matched + unmatched records)
-->--ROJ-Right outer join(matched records + unmatched records from right side table)

SELECT e.employee.employee_id
      ,e.first_name 
      ,e.hire_name
      ,e.salary
	  ,e.department_id 
	  ,d.department_name
FROM employees e,departments d
WHERE e.department_id(+)=d.department_id;



--LOJ--left outer join(matcched records + unmatched records from left side table)

SELECT e.employee.employee_id
      ,e.first_name 
      ,e.hire_name
      ,e.salary
	  ,e.department_id 
	  ,d.department_name
FROM employees e,departments d
WHERE e.department_id=d.department_id(+);


-->--FOJ--full outer join(matched recorde + unmatched records from both table)

TDB

---

SELECT e.employee_id
      ,e.first_name 
      ,e.hire_name
      ,e.salary
	  ,e.manager_id
	  ,m.first_name   manager_name 
	  ,m.hire_date    man_hdate
	  ,m.salary       man_sal
FROM employees e,departments m 
WHERE e.manager_id=m.employee_id;


---why are all getting salary more than their manager
....
AND e.salary>m.salary;

--why are all hired before their manager
...AND e.hire_date<m.hire_date;

WHERE => ON
      => key words
	     join
		 Right [OUTER] JOIN
         LEFT [OUTER] JOIN
		 FULL [OUTER] JOIN
         INNER JOIN
		 CROSS JOIN 
		 NATURAL JOIN
		 
		 
		 
--full outer join
     
SELECT e.employee_id
           ,e.first_name 
           ,e.hire_name
           ,e.salary
           ,e.department_id
		   ,d.department_name
FROM employees e FULL OUTER JOIN departments d
   ON e.department_id = d.department_id;
   
   
 SELECT e.employee_id
       ,e.first_name 
	   ,e.hire_date
       ,e.salary
       ,e.manager_id
	   ,m.first_name  manager_name
	   ,m.hire_date   man_hdata
	   ,m.slary       man_sal
	FROM employees e INNER JOIN employees m
	 ON e.manager_id=m.employee_id
	 
	 
---unmatched records from table = FOJ-Equi
---unmatched records from table = ROJ-Equi	 
---unmatched records from table = LOJ-Equi






CROSS JOIN

  what?
      wrong join | cartesion join 
      it will happan if you ignore the join condition / invalid join condition
  
  how to ignore
       we need to give valid condition
	   
  result
      m*n \ cartesion product




SELECT e.employee_id
       ,e.first_name 
	   ,e.hire_name
       ,e.salary
       ,e.manager_id
	   ,m.first_name  manager_name
	   ,m.hire_date   man_hdata
	   ,m.slary       man_sal
	FROM employees e CROSS JOIN employees m;
	
11499 rows returned in 0.26 seconds
   SELECT 107*107 FROM dual;
   
  SELECT*FROM employees,departments;
  

---selecting data from 3 diff table 
  
    SELECT e.employee_id
       ,e.first_name 
	   ,e.hire_name
       ,e.salary
       ,e.department_id
	   ,d.department_name
	   ,l.street_address
	FROM employees e,department d, location l
	WHERE e.department_id=d.department_id
	AND d.location_id=l.location_id;
	
	
	
--100 table | how many coding required?
99
n   n-1



WHERE e.depatment_id=d.department_id;
WHERE d.department_id=e.department_id;


--always keep the table which contains less no of records on left of the condition 
----l-->R

Natural join
non_inner join
USING clause




SELECT e.employee_id,e.first_name,e.hire_date,e.salary,department_id,d.department_name
  FROM employees e NATURAL JOIN departments d;
  
 SELECT department_name,location_id,street_address
   FROM departments d NATURAL JOIN locations l;
   
   
--no need mention the join condition
--natural join=eqiu join


USING 
SELECT department_name,location_id,street_address
   FROM departments d JOIN locations l
 USING(location_id);
 
 
 non inner join
 
 l_limit    u_limit   offer_pct
--------------------------------- 
    1         5000      10
    5001      100000    25
	100001    500000    50
---------------------------------


   name          bill_name
-----------------------------
Saravana         250000
Karthi           560
Rahul	         75000
Neena            1600
-----------------------------

SELECT od.name,od.bill_amt,of.offer_pct
FROM off_tb of,odr_tb od
WHERE od.bill_amt BETWEEN of.l.limit AND of.u_limit;









	
	
	
	
	
	

  
















	  
	 
	 
	 
	 
	 
	 
	 
	 
   
   
   








	   






















