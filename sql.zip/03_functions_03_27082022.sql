Type conversion

	TO_NUMBER()
	TO_DATE()
	TO_CHAR()
	TO_TIMESTAMP()

TO_NUMBER()
	
SELECT 5 + '5' FROM dual;
SELECT 5 + TO_NUMBER('5') FROM dual;

SELECT 'AK' || 47  FROM dual;
SELECT 'AK' || TO_CHAR(47) FROM dual;

SELECT 100 + TO_NUMBER('10,500','99,999') FROM dual;

SELECT employee_id ,first_name ,hire_date ,salary ,department_id FROM employees
WHERE hire_date = TO_DATE ('17-06-1987','DD-MM-YYYY');

SELECT employee_id ,first_name ,hire_date ,TO_CHAR(hire_date,'DD/MM/YYYY')new_format
FROM employees;

DD             DDD                              MM              YY         HH:MI:SS        J    -JUlien
DDth           D(1-7| sunday to saturday)       MON             YYYY       HH24:MI:SS      Jsp
DDspth         Dy                               MONTH           YEAR       am
               Day                                                         RM


--27th of August , 2022(saturday) "of" "(" ")"

SELECT employee_id,first_name ,hire_date,TO_CHAR(hire_date,'YYYY') yr
FROM employees
WHERE TO_CHAR(hire_date,'YYYY')='1994';

SELECT employee_id,first_name,hire_date ,TO_CHAR(hire_date,'day') yr
FROM employees
WHERE TO_CHAR(hire_date,'DD')=17;

char TO_DATE
date TO_CHAR


SELECT INITCAP(TO_CHAR(TO_DATE('5867'),'JSP')) amount
FROM dual;

--WHERE TRIM(TO_CHAR(hire_date,'Day')) IN('Monday','Tuesday','Wedneday');

--General Function | NULL Function 

------Mainly used to process NULL VALUE

NVL()
NVL2()
NULLIF()
COALESCE()


NVL() - 2 arg | if the first arg value is NULL it will get replaced with second arg else same value 

SELECT employee_id,first_name ,salary, commission_pct,NVL(commission_pct,0)com_pct
FROM employees;

SELECT employee_id ,first_name ,salary,commission_pct,NVL(TO_CHAR(commission_pct),'NO.commission') com_pct
FROM employees;

-- NVL2()

SELECT NULLIF (1,1), NULLIF (1,2) ,NULLIF(2,1), NULLIF(2,2) FROM dual;

--COALESCE()

SELECT COALESCE(NULL,84,NULL,NULL,NULL,65,NULL,86) FROM dual;

--******************************************

SELECT GREATEST(55,85,634,87,23) FROM dual;

SELECT LEAST (100,67,646,49,2) FROM dual;

Multiple ROW Function (n->1)

 Group Function / Aggregate Function
 
 Group Function / Aggregate Function 

MIN()
MAX()
SUM()
AVG()
COUNT()  *|1 -- Count consider NULL value 
 
SELECT MIN(Salary) FROM employees;
SELECT MAX(Salary) FROM employees;
SELECT SUM(Salary) FROM employees;
SELECT ROUND(AVG(Salary)) FROM employees;
SELECT COUNT(employee_id) FROM employees;
SELECT COUNT(NVL(commission_pct,0)) FROM employees;

SELECT COUNT(*) FROM employees;
WHERE department_id=30;

SELECT MIN(Salary), MAX(salary), SUM(salary) FROM employees;

SELECT department_id , MAX(salary) FROM employees;

--ORA 00937 : not a single-group group FUNCTION

A 
A 
A 
B 
C 
C 
D 
-
-
-

--department wise maximum salary 

SELECT department_id, MAX(salary) FROM employees
FROM employees 
GROUP BY department_id
ORDER BY 1;

--No of employeess working in each department

SELECT department_id,COUNT(*) FROM employees
GROUP BY department_id
ORDER BY 1;

--Salary allocated for each department

SELECT department_id,SUM(salary) FROM employees
GROUP BY department_id
ORDER BY 1;

--Arg salary for each department 

SELECT department_id,ROUND(AVG(salary)) FROM employees
GROUP BY department_id
ORDER BY 1;

--ORA-00934 group function is not allowed here

SELECT department_id,COUNT(*) FROM employeess
GROUP BY department_id
HAVING COUNT(*)>30
ORDER BY 1;

SELECT department_id,SUM(salary) FROM employees
WHERE department_id IN(10,20,30,40,50)
GROUP BY department_id
HAVING SUM(salary)>100000
ORDER BY 1;

SELECT			FROM 
FROM			WHERE
WHERE			GROUP BY
GROUP BY 		HAVING
HAVING			SELECT
ORDER BY 		ORDER BY

SELECT standard, COUNT(*) FROM STUDENT_tb
WHERE standard IN('I','II','III','IV','V')
GROUP BY standard
HAVING COUNT(*)>50
ORDER BY 1;

SELECT MAX(salary) FROM employees 
HAVING MAX(salary)<30000;

		WHERE clause                                                     HAVING clause
	---------------------------------------------------------------------------------------------
	Follows FROM Clause                                              Follows GROUP BY
	
	Normal condition                                            condition Depends  on GROUP FUNCTION
	
	Restriction will happen 
	After fetching                                                        After GROUPING
-----------------------------------------------------------------------------------------------------------

SELECT COUNT(*)  FROM employees
WHERE department_id IN(10,20,30);

SELECT department_id,Count(*) FROM employees
WHERE department_id IN(10,20,30)
GROUP BY department_id;

SELECT SIGN(id),SUM(id) FROM sign_tb
GROUP BY SIGN(id);	

