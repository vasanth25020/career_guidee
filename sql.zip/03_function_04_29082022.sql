DECODE()FUNCTION
case expression 
SELECT DECODE ('superman','superman','option_01','other option')result 
FROM dual;

SELECT DECODE('spiderman','superman','option_01'
						 ,'spiderman','option_02'
						 ,'normalman','option_03'
						 ,'other option')result
FROM dual;

SELECT employee_id
       ,first_name
	   ,hire_date
	   ,salary
	   ,department_id 
	   ,CASE
	   WHEN department_id=10 THEN 'administration'
	   WHEN department_id=20 THEN 'marketing'
	   WHEN department_id=30 THEN 'purchasing',
	   WHEN department_id=40 THEN 'human resource'
	   ELSE 'other department'
	   END department_name
	   FROM employees
	   WHERE department_id IN (10,20,30,40,50,60)
	   ORDER BY 5;
	   
	   

SELECT employee_id
       ,fiest_name
	   ,hire_date
	   ,salary
	   ,department_id 
	   ,CASE department_id
WHEN 10   THEN 'administration'
WHEN 20   THEN 'marketing'
WHEN 30   THEN 'human resource'
WHEN 40   THEN 'purchasing'
ELSE'other department'
END deparment_name
FROM employees
WHERE department_id IN (10,20,30,40,50,,60)
ORDER BY 5;

<=10000 Low 1 <=20000 Medium 1>20000 high 

--Realtime usage

DECODE() function
     memory save
        PFA-pendig for approval
         A-approval		
         R-rejected
		 
CREATE TABLE students_tb
  (stud_name VARCHAR(30)
  ,course_name VARCHAR(30));
  
BEGIN

INSERT INTO students_tb values('name_01','Big Data');
INSERT INTO students_tb values('name_02','oracle');
INSERT INTO students_tb values('name_03','AWS');
INSERT INTO students_tb values('name_04','C++');
INSERT INTO students_tb values('name_05','DeVOps');
INSERT INTO students_tb values('name_06','java');
END;
/
SELECT*FROM students_tb
ORDER BY DECODE (course_name,'Big Data')1
                              'oracle',2
							  'devops',3
							          ,4)ASC;
									  
SELECT employee_id,first_name,hire_date,salary,TO_CHAR(hire_date,'MONTH')"hired month"
FROM employees
ORDER BY ASC;
  
 SELECT DECODE (NULL,NULL,'same','Diff') result
FROM dual;


 DECODE                                          CASE 
--------------------------------------------------------------------------------
function                                 expression

exact match                              we can use all operators  
										multiple condition (AND/OR)
										
oracle statement                         ANSI satndard

SQL statement                             SQL and PLSQL

slow                                      fast

--------------------------------------------------------------------------------

what?|opretor |standard|statement|performance

UPDATE table_name
 SET gender =DECODE(gender,'M','F','M');
 
 
