--CONSTRAINT--

CREATE TABLE students_tb
 ,s_id              NUMBER 
 ,s_name            VARCHAR2(30) NOT NULL 
 ,email             VARCHAR2(30) 
 ,gender            CHAR 
 ,department_name   NUMBER  
 ,CONSTRAINT stud_id_pk PRIMARY KEY (s_id)
 ,CONSTRAINT stud_email_uk UNIQUE (email)
 ,CONSTRAINT stud_d_id_fk  FOREIGN KEY (department_id)
                           REFERENCES departments(department_id)
 ,CONSTRAINT stud_gen_ck   CHECK (gender IN('M','F','m','f'));
 
 ALTER TABLE students_tb
	ADD CONSTRAINT stud_d_id_fk  FOREIGN KEY (department_id)
                           REFERENCES departments(department_id)
                           CASCADE;
						   
 ALTER TABLE students_tb
	ADD CONSTRAINT stud_d_id_fk  FOREIGN KEY (department_id)
                           REFERENCES departments(department_id)
                           SET NULL;

 ALTER students_tb
 MODIFY first_name VARCHAR2(30) NOT NULL;
 
 --DELETE FROM departments WHERE deoartment_id=90;
 --ORA-02292:integrity constraint (HR.EMP.DEPT_FK)violated -Child record found 
 
 ALTER TABLE students_tb
  DISABLE CONSTRAINT stud_d_id_fk;
  
  
 ALTER TABLE students_tb
  ENABLE CONSTRAINT stud_d_id_fk;
  
  
 ALTER TABLE students_tb
 DROP CONSTRAINT stud_d_id_fk;
 
 SELECT*FROM user_constraints WHERE table_name='STUDENTS_TB';
 
 SELECT*FROM user_cons_columns WHERE  table_name='STUDENTS_TB';
 
 SELECT*FROM DICT WHERE table_name LIKE '%USER_CONS%';
 
 ALTER TABLE employees
 ADD CONSTRAINT emp_m_id_fk FOREIGN KEY(manger_id)
                            REFERENCES employees(employee_id);
							