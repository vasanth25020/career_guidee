TCL-Transaction Control Language

	COMMIT  --save
	ROLLBACK
	SAVEPOINT
	
Transaction?--list of stmt which we executed between 2 commit points

CREATE t1
t1->10
t1->20
t1->30

COMMIT;
t1->40
t1->50

CREATE t2-> --COMMIT
t2->100
t2->200

ROLLBACK;

SELECT * FROM testdt;
SELECT * FROM recyclebin;
DROP TABLE testdt;
FLASHBACK TABLE testdt TO BEFORE DROP;
DROP TABLE testdt PURGE;

--MERGE (Insert+option)

    src_tb                trg_tb
  id   name             id     name
-------------        ----------------
10    name1             10     name1 
20    siva              20     siva 
30    name3             30     name3



when matched->remaining column will get updated
when not matched->get inserted

CREATE TABLE src_tb(id NUMBER,name VARCHAR2(30));
CREATE TABLE trc_tb AS SELECT * FROM scr_tb WHERE 1=2;

INSERT INTO src_tb VALUES(10,'nmae_01');
INSERT INTO src_tb VALUES(20,'name_02');

MERGE INTO trg_tb t
USING scr_tb s
ON (s.id=t.id)
WHEN NOT MATCHED THEN
    UPDATE
	   SET t.name=s.name;
	   
INSERT INTO src_tb values(30,'name_03');
INSERT INTO src_tb values(40,'name_04');
UPDATE src_tb 
   SET name='saravanan'
 WHERE id=20;
 
 src -> table | sub query
WHEN matched THEN | optional DELETE with WHERE clouse
we cant update the column which is used as a condition


--ROLLUP/CUBE

SELECT department-id,COUNT(*)no_of_emp
  FROM employees
 WHERE department-id IS NOT NULL
GROUP BY ROLLUP(department-id)
ORDER BY 1;

SELECT department-id,job_id,COUNT(*)no_of_emp
  FROM employees
 WHERE department-id IS NOT NULL
GROUP BY ROLLUP(department-id,job_id)
ORDER BY 1;


--local user | outer user | other database 
--FAQ | what is DbLink?

--citiDB
--HR
SELECT * FROM employees;
SELECT * FROM hr.employees;

--system 
SELECT * FROM hr.emplouyees;

--HDFC
SELECT * FROM hr.employees@citiDB;
SELECT * FROM hr.employees@<dblink>;

-- DCL - Data Control Language | DBA(user managment)
   GRANT
   REVOKE
   
 shema +  -
      lock | unlock 
	  password -physical file 
	  
1 tbs-1 data file -Big Dataspace 
1 tbs - multiple Data File-small Tablespace 

    8 blocks-extend 

user tablespace 
   USERS
   SYSTEM
   SYSAUX
 temporary tablespace --ORDERBY | DISTINCT | salary*12 | GROUP BY
    Temp 
undo tablespace 
    uncommited information - 15min(9000sec)-snapshot error
	
	
	CREATE USER sep 
	INDENTIFIED BY sep123
	DEFAULT TABLESPACE USERS
	TEMPORARY TABLESPACE temp 
	QUOTA 10M ON USERS
	QUOTA 10M ON SYSAUX
	PASSWORD EXPIRE;
	
SELECT username,account_status,default_tablespace,temporary_tablespace
   FROM dba_users
  WHERE username='SEP';
  
 CREATE TABLE myemployees(id NUMBER,name VARCHAR2(30));
 INSERT INTO myemployees(SELECT employee_id,first_name,FROM hr.employees);
 
 SELECT*FROM employees;
 
 GRANT SELECT,INSERT,UPDATE ON myemployees to sep;
 REVOKE SELECT,INSERT,UPDATE ON myemployees tp sep;
 
 CREATE SESSION/CREATE TABLE--session level 
 SELECT,INSERT,UPDATE/READ,WRITE--object level permission 
 
 CREATE ROLE manager;
 GRANT p1,p2,p3....p150 to manager;
 
 GRANT manager to rahul,steven,neena;
 
 GTT|PTT|Data Dict TABLE
 how to learn?
 
 --Data Dict TABLE
 SELECT*FROM user_tab_columns
 WHERE table_name='EMPLOYEES'AND DATA_TYPE='VARCHAR2';
 
 SELECT DISTINCT table_name
   FROM user_tab_column WHERE column_name='DEPARTMENT_ID';
   
   
   
 --user_      |   all      |  dba_
HR user(user_)....10tb
HR(all)        ......12 tables 
admin          ......dba_

------
dict
user_ tables  
user_ views 
user_ sequences    
user_ synonyms
user_ indexes 
all objects
user_contraints 
user_ cons_columns   
dba_users
user_tab_columns

--Data | mate Data 

GTT - Global Temporary Table  | 8i

   ON COMMIT DELETE ROWS
   ON COMMIT PRESERVE ROWS 
   
CREATE GLOBAL TEMPORARY TABLE test_gtt1
(id NUMBER) ON COMMIT PRESERVE ROWS;

--session wise table | TRANCATE session wise data will get removed
--temp tablespace 
--index possible 

--PTT | 18c

ON COMMIT DROP DEFINITION
ON COMMIT PRESERVE DEFINITION	
 
 PTT ORA|PTT_
	
	
	
	
	
	
	
	
	
	
	
	