													 FUNCTION


-->>-- FUNCTION
	  --single row function (n->n)
      --multiple row function (n->1)
		
		
-->>--Single Row Function  (n->n)

    -->--case function 

		--case multiplication function
		
			UPPER()		LOWER()		INITCAP()

		--character multiplication Function
			LENGTH()
			CONCAT()
			REVERSE()
			SUBSTR()
			INSTR()
			LPAD()		RPAD()
			LTRIM()		RTRIM()		TRIM()
			REPLACE()		TRANSLATE()
			
	-->--Number function

		ROUND()		TRUNC()		MOD()		POWER()
		ABS()		SIGN() 		CEIL()		SQRT()
		
	-->--Data function

		MONTHS_BETWEEN()
		ADD_MONTHS()
		NEXT_DAY()
		LAST_DAY()
		
	-->--type conversion
		
		TO_NUMBER()
		TO_CHAR()
		TO_DATE()
		TO_TIMESTAMP()
		
	-->--general function / NULL function
		NVL()		NVL2()   NULLIF()  COALESCE()
		
		
-->>--multiple row function (n->1)		
      
	--  group funtion / aggregate function
	  MIN()   MAX()   SUM()   AVG()   COUNT()
	  
			GROUP BY
			HAVING


DECODE() FUNCTION
   case expression




-->>--case function 


--case manipulation   

SELECT first_name,UPPER(first_name),LOWER(first_name),INITCAP(first_name)
 FROM employees;
 
SELECT INITCAP ('welcome to infycle technologies')wel_text FROM dual;

SELECT first_name,hire_date,salary,department_id
  FROM employees
  WHERE LOWER(first_name)=LOWER('stEvEn');
  


--character manipulation
 
 SELECT first_name
 ,LENGTH(first_name)
 ,CONCAT(first_name
 ,last_name)
 ,INITCAP(REVERSE(first_name)) rev_name  ---255
 FROM employees;
 

--SELECT first_name FROM employees WHERE first_name LIKE'____';
  SELECT first_name FROM employees WHERE LENGTH (first_name)=5;
  

 --WHERE department_id=10 OR department_id=20 OR department_id=30;
 WHERE department_id IN(10,20,30);
 

 --WHERE salary>=6000 AND salary<=7000;
  WHERE salary BETWEEN 6000 AND 7000;
  
 WHERE hire_date LIKE'%94';
 WHERE hire_date BETWEEN '01-JAN-94' AND '31-DEC-94';
 
-->>-- SUBSTR() & INSTR()

 --SUBSTR()
   used to get part of the string
   
   arg1-> input string
   arg2-> starting
   arg3-> no of characters to print
   
SELECT first_name
 ,SUBSTR(first_name,1,3) "SUB_01"
 ,SUBSTR(first_name,2,3) "SUB_02"
 ,SUBSTR(first_name,3,2) "SUB_03"
 ,SUBSTR(first_name,3  ) "SUB_04"
 ,SUBSTR(first_name,-2,2)"SUB_05"
 ,SUBSTR(first_name,6,2) "SUB_06"
 FROM employees;
 
welcome 
SELECT SUBSTR('welcome',-3,2) FROM dual;


--INSTR()
 arg1-> input(ex:first_name)
 arg2-> choose searching value(ex:i)
 arg3-> searching start point
 arg4-> ethanayavathu character place 
 
 SELECT first_name		
		,INSTR(LOWER(first_name),'a'    ) "INSTR_01"
		,INSTR(LOWER(first_name),'a',1,2) "INSTR_02"
		,INSTR(LOWER(first_name),'a',1,3) "INSTR_03"
	FROM employees;
	
SELECT 'murugappan',INSTR('murugappan','u',1,2) INSTR_TXT FROM dual;

						INSTR_01	INSTR_02	INSTR_03 	INSTR_04
2 or more no of a 		   <>0     	   
exactly 3 no of a          <>0         =0
3 or more no of a          <>0
exactly 3 no of a          <>0         =0


--Display all the first_name which contains second character as all
             (LIKE|SUBSTR)
LIKE -> SELECT first_name FROM employees;
         WHERE first_name LIKE'_a%';
SUBSTR->SELECT first_name FROM employees
		 WHERE SUBSTR(first_name,2,1)='a';
		 
--Display all the name which starts with a,e,i,o and u 
    WHERE SUBSTR(LOWER(first_name)1,1) IN ('a','e','i','o','u')
	ORDER by 1 ASC
	
TABLE CREATING
	
  CREATE TABLE student_info_tb(email_id VARCHAR2(30));
  INSERT into student_info_tb values('murugappan@gmail.com');
  INSERT into student_info_tb values ('jhon@gmail.com');
  INSERT into student_info_tb values ('kumar.456@gmail.com');           


ram@gmail.com 			ram 		gmail.com 
saravanan@gmail.com    saravanan    gmail.com 

LPAD()				RPAD()

SELECT first_name
  ,salary
  ,LPAD(salary,8,0)
  ,RPAD(salary,8,'X')
  FROM employees;
  
  9       cap      100.00
  10    key board 7180.00
  11    cup         10.00
  
  SELECT LPAD(employee_id,s,'')||''||RPAD(first_name 13,'')||''||LPAD(salary.6) salary_detail
		FROM employees
	WHERE department_id IN (10,60,90);
		
---LTRIM() | RTRIM()  | TRIM()

SELECT '0000000012708900000000'                  "DATA"
 ,LTRIM('0000000012708900000000','0')            "LTRIM"
 ,RTRIM('0000000012708900000000','0')            "RTRIM"
 ,RTRIM(LTRIM('0000000012708900000000','0'),'0') "TRIM"
 ,TRIM('0' FROM'0000000012708900000000')         "TRIM"
 FROM dual;
 
 SELECT 'murugappan'                    "DATA"
     ,LENGTH('murugappan     ')         "P_LEN"
	 ,LENGTH(TRIM('MURUGAPPAN       ')) "A_LEN"
  FROM dual;
  
SELECT 'welcome to oracle session'  "TEXT"
  REPLACE('welcome to oracle session','lc','XY')  "REPLACE"   --string based
  TRANSLATE('welcome to oracle session','lc','XY')  "TRANSLATE"  ---character based
  FROM dual;
  
  
  SELECT REPLACE('a192r192u192n192','') name from dual;
  SELECT TRANSLATE(a197r9854u4564n2345','0123456789','') FROM dual;
  