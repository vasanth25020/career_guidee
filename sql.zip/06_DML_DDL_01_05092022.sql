
Statement in Oracle
DDL: Data Define Language (CARDT)--Structure
    CREATE
	ALTER --Column Level
	   ADD RENAME MODIFY DROP
	RENAME
	DROP
	TRUNCATE
	
DML: Data Manipulation Language
    INSERT
	UPDATE
	DELETE
	MERGE (INSERT+UPDATE)
	
	--Constraint|sqlplus (Client side
	
TCL: Transaction Controal Language
    COMMIT
	ROLLBACK
	SAVEPOINT
	
DCL:Data Control Language
    GRANT
	REVOKE
	
Data Types in Oracle

NUMBER(P,S)        0-9    employee_id       NUMBER
Size:Optional             salary            NUMBER
Max: 99999.99(38)

sal_pt        569.45
sal_pt     NUMBER(5,2)    --NUMBER(3,2)
           NUMBER(8,3)    --23987.985
		   
VARCHAR
--Variable Character Length
VARCHAR2                0-9                 name        VARCHAR2(30)
SIZE  :  mandatory     a-z | A-Z           email_id     VARCHAR2(30)
MAX   :  4000          special character

--NVARCHAR2

12c

32767
max_string_size (DEFAULT | EXTENDED)

nls_date_format | DD-Mon-YY

--Fixed Chatacter Length
CHAR                    0-9                 name        VARCHAR2(30)
SIZE    : optional      a-z | A-Z           email_id     VARCHAR2(30)
Default : 1             sepecial chatacter

NCHAR
v_a   | C | a | t |  |  |   --3
v_b   | C | a | t |  |  |   --5 space

v_a<>v_b
length(v_a)<>length(v_b)
v_a=TRIM(v_b)
LENGTH(v_a) = LENGTH(v_b)

DATE                   05-SEP-22      _dt
Default size : 7

TIMESTAMP              05-SEP-22 11.31.38.926000 AM +05:30 _dttm

LONG              --per table only one long column is allowed
--2GB             --we cant use it in ORDER BY and GROUP BY
                  --LONG - copy not possible
				  
--large object date types
CLOB
--4GB

--Up to this

BLOB
BFILE
ROWID
RAW
.....

DDL-Data Define  Language(GARDT)

CREATE
ALTER
    ADD RENAME MODIFY DROP
RENAME
DROP
TRUNCATE

-Table Desing Document(Excel)

CREATETABLE incy_students_tb

CREATE TABLE infy_students_tb(stud_id NUMBER, first_name VARCHAR2(50),genter CHAR,dob DATE,department_id VARCHAR2(30));
-Feedback incy_students_tb;

DESC incy_students_tb;

ALTER TABLE incy_students_tb ADD feedback LONG; ALTER TABLE
infy_students_tb RENAME COLUMN first_name TO name;ALTER TABLE infy_students_tb MODIFY department_id NUMBER; ALTER TABLE
infy_students_tb DROP COLUMN feedback;

--feedback: Table altered.

RENAME infy_students_tb TO students_tb; DROP TABLE table_name;
TRUNCATE TABLE table_name;

CTAS

-creating table by using sub query with data CREATE TABLE dept1 AS
(SELECT * FROM depatments WHERE1=1);

-creating table by using sub query with data CREATE TABLE dept1 AS
(SELECT * FROM depatments WHERE1=2);

DML-Data Manipulation Language

INSERT
UPDATE
DELETE
MERGE (INSERT+UPDATE)


CREATE TABLE students_tb(s_id NUMBER,s_name VARCHAR2(30),
dop DATE,job_id VARCHAR2(30) DEFAULT 'IT_PGM',department_id
NUMBER);

-100% INSERT INTO students_tb(s_id,s_name,dop,job_id,department_id) VALUES(1001, 'NAME_01', SYSDATE-8786, 'SAL_MAN',10);

INSERT INTO students_tb VALUES(1002,'Name_02',SYSDATE-1286, 'SAL_REP'30);

INSERT INTO students_tb(s_id, s_name, dob, job_id )VALUES(1003, 'Name_03',SYSDATE-8916,'MANGER');

-Ignore that column from the list |NULL|''

INSERT INTO students_tb(s_id, s_name, dob, job_id )VALUES(1003, 'Name_04',SYSDATE-9986,10);

-Inserting data Using Sub Query INSERT INTO dept2 (SELECT *FROM departments);

-ignore VALUES key word

SELECT*FROM dept1;

UPDATE dept1 SET department_name='Admin' WHERE department_id=10;


UPDATE dept1 SET department_name='Dept Of Admin',manager_id=114,location_id=1800 WHERE department_id=10;


UPDATE dept1 SET department_name='Dept Of Admin',manager_id=114,location_id=1800;

DELETE FROM dept1 WHERE department_id IN(10,30,50,70);

DELETE FROM dept1;

____________________________________________________________________________________________
          TRUNCATE                                   DELETE
____________________________________________________________________________________________
DDL statement                                     DML statement 

We Cant restrict the                         We can restrict the data  
which we are going to delete                Which we are going to remove 

We cant use WHERE clause                    We can use WHERE clause

We can get back the data                    We can getback the data 

ROLLBACK not possible                       ROLLBACK possible

Fast                                        Slow 

table truncated                            5 row(s) deleted 
____________________________________________________________________________________________                    


stmt  | WHERE | data | performance | feedback

-task -max no of columns | max column Length | max_string_size |

nls_date_format-possible tables in - High Watermark(D) | Low Water Mark(T)

->-List out | DDL | DCL | TCL | Listof data Types D B /W DDL & DML | VARCHAR2&VARCHAR | TRUNCATE | DELETE | DROP 



















































