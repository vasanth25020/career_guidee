
 oracle is a database which came to existence in 1969-1970 approx 50 years ago 
						different versions of oracle are
						    6i, 7i, 8i, 9i, 10g, 11g, 12c, 13c, 14c, 20c, 21c.
							
							currently working ith 10g
							
							
							i->internet
							g->grid
							c->cloud
							
  new features ?
					frshers          experieced
					user			 schema
					row				records
					output 			result set

schema objects of sql
					table    -basic unit of storage in a database
					view     -logical representation of subset of a  records 
					sequence -numeric value genarator
					synonym  -used to provide alternative name for an objects 
					index    -one of the performance tuning method 
					
					
												table      -tb			
 Database  -> user(schema) -> schma object -> 	view       -vw				
												sequence   -seq
												synonym    -syn
												index      -ind
												
	RETRIVING DATA
								retriving data
								
								select  from clause 
								
								
								oracle has two ypes of tables 
								
								web tables 
								
								contains user information
								created and maintained by database 
								
arithmetic operaters +-*/


  SELECT employee_id,first_name,Last_name,Salary,salary+5000 From employees;
  in the above query the result set alone has the salary increased by 5000
  but it does not mak any changes in database 
								
	SELECT employee_id,First_name,Last_name,salary,12*salary,FROM employees;
	
	arithmetic operation in order called    
          		  PEMDAS
				  
				  p-paranthesis
				  E-exponential
				  M-multiplication
				  D-Division
				  A-addition
				  S-Subraction
			
as -> Alias 
          
		  used to rename column heading
		  column  name/expression AS "ALIAS_NAME"
		  mostly used with expression
		  
		  
		  
		 SELECT employee_id,first_name,last_name,salary,salary*12 AS"ANN_SAL" FROM employees;
		 SELECT employee_id,first_name,last_name,salary,salary*12   "ANN_SAL" FROM employees;
		 SELECT employee_id,first_name,last_name,salary,salary*12   ANN_SAL   FROM employees;
		 SELECT employee_id,first_name,last_name,salary,salary*12   "ANN_SAL" FROM employees;
		 SELECT employee_id,first_name,last_name,salary,salary*12   "ann_sal" FROM employees;
		 
		 
		 
		 
___||    concatentation or pipe operator
		 concatentation to merge two column into a single column

		SELECT first_name,salary from employees;
		SELECT first_name||salary from employees;		 
		SELECT first_name||''||salary FROM employees;
		SELECT first_name||'salary is'||salary FROM employees;

__ escape sequence
__specially modified in 10G to add literals in srings
__expression Q'[]'

		SELECT first_name||Q'['s]'||'salary is '||salary FROM employees;
		SELECT first_name||Q'['s salary is ]'||salary FROM employees;

if dont want to add escape sequence
we can use two ''literalscan be added to get one literal
		SELECT first_name||'''s salary is '||salary"salary details" FROM employees;
		SELECT ''''''||first_name||'''s salary is'||salary||''''''"salary details" FROM employees
		
		
oracle standards for writing queries
        we can write queriesin multiple lines
		nothing is case sensitive in oracle except data (murugan/Murugan/MURUGAN)
		data is always format sensitive(DD-MON-YY)
		CLAUSES and KEYWORDS -UPPERCASE
		isqlplus;(optional)|sqlplus ;(mandatory)

SELECT employee_id,first_name,hire_date,salary,department_id
FROM employees;


SELECT
		employee_id
		,first_name
		,hire_date
		,salary
		,department_id
		FROM
		employees;
		
		__nothing is case sensitive in oracle except data
		
null->unknown value |unassinged value|unassinged value

null<>0
null<>space
null<>special character(isqlplus-[sqlplus[sql developer (null))
null<>nullnull+2000=null

			SELECT employee_id,first_name,salary,commission_pct
			FROM employees;
			
___to know structure of a table 
		
		
		DESCRIBE|DESC
		DESCRIBE employees;
		DESC departments;
		
DISTINCT

		SELECT department_id FROM employees;
		SELECT DISTINCT department_id FROM employees;
		SELECT UNIQUE department_id FROM employees;
		
		SELECT department_id,job_id FROM employees;
		
		
		__single line comment 
		
	/*
	multiple
	line command
	*/
	
	Dual table
			dummy table in oracle to process our own data
			1 row|multiple columns
			default column name:dummy|default data:x
			data type:VARCHAR2
			owner:SYS
			
	SELECT'MURUGAPPAN ANNA MALAI'name,'45000'salary FROM Dual;
	SELECT12*(1000+100)FROM Dual;
	















