-- Restricting and sorting Data 
 -- 10 60 90 |'steven' 'Sales_man' '21-01-89'|'21-JAN-89'
 --Numeric  VALUES can be written directly without literals.
 --Characters has to written only in literals and also incorrect data format will be taken as a character.
 --data is format sensitive ad can be reorested in a format DD-MON-YY
 
 
 
 WHERE department_id=90;
 WHERE first_name='steven'
 WHERE hire_date='21-JAN-98'
 
 
 
 SELECT employee_id,first_name,hire_date,salary,department_id
   FROM employees
  WHERE department_id=90;
  
 SELECT employee_id,first_name,hire_date,salary,department_id
   FROM employees
  WHERE department_id=90;

 SELECT employee_id,first_name,hire_date,salary,department_id
   FROM employees
  WHERE salary >=17000;
  
   SELECT employee_id,first_name,hire_date,salary,department_id
   FROM employees
  WHERE first_name='steven';
  
   SELECT employee_id,first_name,hire_date,salary,department_id
   FROM employees
  WHERE hire_date='22-SEP-89';
  
--Relational Operaters

       < > <= >= <> != ^=
	   
not equal to can be repsented in three expressios
     <>   !=   ^=

Oracle Special operaters

[NOT] IN
[NOT] BETWEEN...AND...
[NOT] LIKE 
IS [NOT] LIKE

Logical operaters
    AND    OR    NOT
	
	
IN

 SELECT employee_id,first_name,hire_date,salary,department_id
   FROM employees
  WHERE department_id IN(10,60,90);
  
  SELECT employee_id,first_name,hire_date,salary,department_id
   FROM employees
  WHERE department_id IN(10,60,90,NULL);
  
  IN operater will not process NULL VALUE
  
  SELECT employee_id,first_name,hire_date,salary,department_id
   FROM employees
  WHERE first_name IN ('steven','Neena','Lex');
  
  
--!-- WHERE department_id IN(10,60,90,NULL)
--!-- WHERE first_name IN ('steven','Neena','Lex','Rajesekar')

[NOT] IN
 
 NOT IN is opposite to IN operater 

 SELECT employee_id,first_name,hire_date,salary,department_id
   FROM employees
  WHERE department_id NOT IN(10,60,90);
  
 SELECT employee_id,first_name,hire_date,salary,department_id
   FROM employees
  WHERE first_name IN ('steven','Neena','Lex','Rajesekar');
  
When using character in IN operater any cahracter data not in database can be added but the result will only fetch data in table 

[NOT]BETWEEN ...AND...

-- BETWEEN ...AND... operater is used to fetch data when we have range of values.
  
  SELECT employee_id,first_name,hire_date,salary,department_id
   FROM employees
  WHERE salary BETWEEN 6000 AND 7000;
  
--When regular values between not have and values but in sql 
-- BETWEEN AND operater will include and values 


SELECT employee_id,first_name,hire_date,salary,department_id
   FROM employees
  WHERE hire_data BETWEEN '1-JAN-94' AND '31-DEC-94';
  
--WHERE grd BETWEEN 'C'AND 'F';

SELECT employee_id,first_name,hire_date,salary,department_id
   FROM employees
  WHERE salary NOT BETWEEN 6000 AND 7000;

--Like pattern matching | wildcard search
% something|nothing 
--one  characters
 
SELECT first_name FROM employees WHERE first_name LIKE 's%';
SELECT first_name FROM employees WHERE first_name LIKE '%n';
SELECT first_name FROM employees WHERE first_name LIKE 's%n';
SELECT first_name FROM employees WHERE first_name LIKE 'steven%';
SELECT first_name FROM employees WHERE first_name LIKE '%man';
SELECT first_name FROM employees WHERE first_name LIKE '_t%';
SELECT first_name FROM employees WHERE first_name LIKE '___v%';
SELECT first_name FROM employees WHERE first_name LIKE '_t_v%';
SELECT first_name FROM employees WHERE first_name LIKE '_____';

Implementation LIKE operater 

SELECT * FROM students_tb WHERE table_name LIKE 'STU%';
SELECT * FROM students_tb WHERE email='ram@gmail.com';
SELECT * FROM students_tb WHERE email LIKE'__e%';
SELECT * FROM students_tb WHERE email LIKE '_____/%' 'ESCAPE'/';
SELECT * FROM students_tb WHERE email  LIKE'_____$_%'ESCAPE'$';

90    97%   9   100%

SELECT * FROM students_tb WHERE pct_val LIKE '%/%'ESCAPE'/;


IS [NOT] NULL
   WHERE department_id=NULL; 
   WHERE department_id='';
   WHERE department_id='   ';
   WHERE department_id='NULL';
 
--'|NULL (to insert NULL values)

SELECT employee_id,first_name,hire_date,salary,commission_pct 
 FROM employees
WHERE commission_pct is NULL;

SELECT employee_id,first_name,hire_date,salary,commission_pct 
 FROM employees
WHERE commission_pct is NOT NULL;

SELECT employee_id,first_name,hire_date,salary,department_id 
FROM employees
WHERE department_id is NULL;

--Logical operaters AND OR NOT 
--WHERE department_id=60 OR 90

SELECT employee_id,first_name,hire_date,salary,department_id 
FROM employees
WHERE department_id=60 OR department_id=90;

SELECT employee_id,first_name,hire_date,salary,department_id 
FROM employees
WHERE first_name=60 OR department_id='steven' OR department_id=90;

SELECT employee_id,first_name,hire_date,salary,department_id 
FROM employees
WHERE first_name=60 OR department_id='steven' AND department_id=90;

--whwn AND and OR operater are written in single querey without brackets
--AND operater executes first and then OR operater executes.

SELECT employee_id,first_name,hire_date,salary,department_id 
FROM employees
WHERE (department_id=90 OR department_id=50) first_name='steven';

    red|S
	balck|M 

WHERE(color=red OR size='s')AND(color+black OR size='M')


Sorting
ORDER BY (comes at last)
ASC(default)
DESC

SELECT employee_id,last_name,hire_date,salary,department_id
FROM employees
ORDER BY first_name ASC;

SELECT employee_id,last_name,hire_date,salary,department_id
FROM employees
ORDER BY first_name DESC;

SELECT employee_id,last_name,hire_date,salary,department_id
FROM employees
ORDER BY first_name;

SELECT employee_id,last_name,hire_date,salary,department_id
FROM employees
ORDER BY 2 DESC;

--positional based sorting

SELECT employee_id,last_name,hire_date,salary,department_id
FROM employees
ORDER BY 4 ASC;

SELECT employee_id,last_name,hire_date,salary*12,department_id
FROM employees
ORDER BY ASC;

SELECT employee_id,last_name,hire_date,salary,department_id
FROM employees
ORDER BY department_id,salary;


SELECT employee_id,last_name,hire_date,salary,department_id
FROM employees
ORDER BY 5,4;

SELECT employee_id,last_name,hire_date,salary,department_id
FROM employees
ORDER BY department_id DESC NULLS LAST;


SELECT employee_id,last_name,hire_date,salary,department_id
FROM employees
ORDER BY department_id DESC NULLS FIRST;
