---VIEW (_vw) [DATA] (No Data )

    Logical Representation of subset of records
    It act a window to View data from the table 
    We wont contains any data 
    View is a Schema Object 
    Data Dict Table :User Views 

Types of View 
    Simple View-Selecting Dat From Single Table 
    Complex View-Selecting Dat From Multiple Table 

--Simple view 

CREATE VIEW exec_vw
AS 
SELECT employee_id,first_name,hire_date,salary,department_id
FROM employees
WHERE department_id=90;

--Dont DROP and RECREATE |Use CREATEOR REPLACE

 CREATE OR REPLACE VIEW exec_vw 
 AS
 SELECT employee_id,first_name,hire_date,job_id, salary,department_id
FROM employees
WHERE department_id=90;

SELECT * FROM exec_vw;

--Complex View 
 CREATE OR REPLACE VIEW all_info_vw
 AS
 SELECT d.department_name
        ,MIN(salary)        min_sal
		,MAX(salary)        max_sal
		,ROUND(AVG(salary)) avg_sal
	FROM employees e,departments d 
	WHERE e.department_id=d.department_id
	GROUP BY d.department_name
	ORDER BY 1;
	
SELLECT employee_id,first_name,salary
  FROM exec_vw;
  
 CREATE OR REPLACE VIEW sal_details_vw 
 AS 
 SELECT employee_id,first_name,salary,salary*12 ann_sal
 FROM employees;
 
 SELECT * FROM sal_details_vw;
 
 
 --Realtime | Task :Need to add 2 columns (+2 columns  +2 alias name)
 
 CREATE OR REPLACE VIEW sal_details-vw (employee_id,name,sal,ann_sal)
 AS
 SELECT employee_id,first_name,salary,salary*12
 FROM employees;
 
--Advantage of creating View 
    We can restrict Data Access 
	We can pprovide the data whatever they want 
	We can represent the Data in different from 
	We can make complex Query Simple
	
--DML possible on view?
Simpe View --Possible 
Complex View --No Possible 

Simple View 

DELETE NOT Possible 
  DISTINCT/UNIQUE 
  psedocolumns
  GROUP Function 
  GROUP BY 
  column Defined Expression (Salary*12)

INSERT NOT POSSIBLE 
  DISTINCT/UNIQUE 
  psedocolumns
  GROUP Function 
  GROUP BY 
  column Defined Expression (Salary*12)
 
 C1  C2  C3  C4  C5 
         C3  C4  C5 (Remaining column have NULL)
		 
  If you have primary key/NOT NULL constraint on the column  which is not selected in the view means-INSERT NOT POSSIBLE 
  
  
 --It will not allowed you to violate the condition which you mentioned in WHERE clause 
  CREATE OR REPLACE VIEW it_emp_vw
  AS 
  SELECT employee_id,first_name,hire_date,salary,department_id
  FROM employees 
  WHERE department_id=60 WITH CHECK OPTION;
  
 --DML not Possible 
  CREATE OR REPLACE VIEW it_emp_vw 
  AS 
  SELECT employee_id,first_name,hire_date,salary,department_id
  FROM employees 
  WHERE department_id=60 with READ OPTION;
  
 DESC it_emp_vw
 
 SELECT text 
  FROM _VIEWS 
 WHERE view_name=UPPER('it_emp_vw');
 
 table->view 
 view->view 
 table join view -> view 
 view join view ->view 
 
--is it possible to create index on view?
  Index possible on view 

--SET Operaters 
  
    UNION 
	UNION ALL 
	INTERSECT 
	MINUS
	
	A  = 1  2  3  4  5  
	B  = 4  5  6  7  8

A UNION      B = 1  2  3  4  5  6  7  8(no duplicate)
A UNION ALL  B = 1  2  3  4  5  6  7  8(Include Duplicate)
A INTERSECT  B = 4 5
A MINUS	     B = 1 2 3
B MINUS      A = 6 7 8 

A MINUS    B = 1 2 3 
UNION 
B MINUS    A = 6 7 8 
DROP TABLE dept 1;

CREATE TABLE dep1
AS 
SELECT department_id,department_name,manager_id,locatgion_id
 FROM departments WHERE department_id IN(10,40,30,20,50)
ORDER BY department_name DESC;

CREATE TABLE dept2 
AS
SELECT department_id,department_name,manager_id,location_id 
 FROM departments WHERE department_id  IN(80,40,60,70,50);
 
--UNION |ignore Duplicate |sort the data in ASC order 

 SELECT department_id,department_name,manager_id,location_id FROM dept1
 UNION
 SELECT department_id,department_name,manager_id,location_id FROM dept2;
 
--UNION ALL |Includes Duplicates |No sorting 
 
SELECT department_id,department_name,manager_id,location_id FROM dept1
UNION ALL
SELECT department_id,department_name,manager_id,location_id FROM dept2;
 
--Performance UNION<UNION ALL 
 
SELECT department_id,department_name,manager_id,location_id FROM dept1
INTERSECT
SELECT department_id,department_name,manager_id,location_id FROM dept2;
 
 
SELECT department_id,department_name,manager_id,location_id FROM dept1
MINUS
SELECT department_id,department_name,manager_id,location_id FROM dept2;
 
No of Column Must be same(NULL)
order of the data type (type conversion function)
Top to Bottom 
First Query Alias name/column Nam e will be used for entire resultset 
ORDER BY clause will be used only in last query 
 
 q1        (q1
 UNION     UNION 
 q2         q2)
 MINUS     MINUS 
  q3        (q3 
 UNION     UNION 
  q4         q4)
  
  
Difference Between union and join 
Difference Between union and union all 

t1
---
id 
1
2
2
3
4
5

SELECT id FROM t1
UNION 
SELECT id FROM t1;

--How to get DISTINCT Records From first_name column
 
 SELECT first_name FROM employees 
 UNION 
 SELECT first_name FROM employees;
 
--CONNECT BY | LEVEL 
SELECT LEVEL 
CONNECT BY LEVEL <=10;

SELECT SUBSTR ('infycle',LEVEL,1)
  FROM DUAL
CONNECT BY LEVEL <= LEMGTH ('infycle');

infycle
i
n 
f 
y 
c 
l 
e 

i 
in 
inf 
infy 
infyc 
infycl 
infycle 

--Based on give input data | print all the data in that particular month 

Date-All Date in that Particular Month 
Date-All Date in that particular  year 

Display all the Weekends in next 100 days 

SELECT SYSDATE -1 +LEVEL,TO_CHAR (SYSDATE -1 =LEVEL 'day')day 
FROM DUAL 
WHERE TO_CHAR(SYSDATE -1 + LEVEL ,'D') NOT IN (1,7)
CONNECT BY LEVEL <=100;
 
  