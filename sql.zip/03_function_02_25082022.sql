Number Function

ROUND() TRUNC() MOD() POWER() 
ABS() SIGN() CEIL() FLOOR() SQRT()

--ROUND()  default 0

+ve \ you need to check next values
		
		>=5 \ +1
		Else \ same value 
		
SELECT 
		ROUND(687.435,2) "ROUND_01"
		ROUND(687.432,2) "ROUND_02"
		ROUND(687.492,2) "ROUND_03"
		ROUND(687.432,2) "ROUND_04"
		ROUND(687.432,2) "ROUND_05"
		ROUND(687.432,2) "ROUND_06"
		ROUND(687.432) "ROUND_07"
	FROM dual;
	
-ve \ you need to check same value

		-1		10
		-2		100
		-3		1000
		
SELECT 
		ROUND (682.435,-1) "ROUND_01"
		ROUND (682.43,-1) "ROUND_02"
		ROUND (682.432,-2) "ROUND_03"
		ROUND (682.432,-3) "ROUND_04"
		ROUND (627.432,-3) "ROUND_05"
		ROUND (387.432,-3) "ROUND_06"
		ROUND (1387.432,-3) "ROUND_07"
		ROUND (1987.432,-3) "ROUND-08"
	FROM dual;
	
--ROUND() \ lower limit

SELECT TRUNC (9856.78,-3) "TRUNC_01"
		TRUNC (9256.36,-3)"TRUNC_02"
	FROM dual;
	
SELECT MOD(10,3) , MOD (-18,5) FROM dual;

--Display all add/even employee_id 

SELECT Power (2,2), Power (5,5) FROM dual;

SELECT AES(-10), AES(10) FROM dual;

SELECT SIGN(-10), SIGN(10) FROM dual;

--FAQ

CREATE TABLE sign_tb (id number);
INSERT INTO sign_tb VALUES(-1);
INSERT INTO sign_tb VALUES(-12);
INSERT INTO sign_tb VALUES(100);

SELECT id, sign(id) FROM sign_tb;

--Write a quary to print all positive values
--Write a query to print all negative values 
--Write a quray to print sum of all positive values
--Write a quray to print sum of all negative values

SELECT CEIL (6,7) , CEIL (6,3) FROM dual;
SELECT FLOOR (6,7), FLOOR (6,3) FROm dual;
SELECT SQRT (25) FROM dual;

Date Function

MONTHS_BETWEEN() --Return number of output
ADD_MONTH()
NEXT_DAY()
LAST_DAY()

SELECT sysDate FROM dual;
SELECT SysDate +15 FROM dual;
SELECT SysDate -250 FROm dual;
SELECT ROUND(SYSDATE - to_DATE ('21-AUG-22'))||'DAYS' "DIFF" FROm dual;

SELECT SYSDATE + To_DATE('21-AUG-22') FROM dual;

		DATE + Number = DATE 
		DATE - Number = DATE 
		DATE - DATE   = Number
		DATE + DATE   = Error (ORA-00975:date + date not allowed )
		
SELECT ROUND (MONTHS BETWEEN (SYSDATE,'15-AUG-20')) MONTHS_BETWEEN FROM dual;

SELECT ROUND(MONTHS_BETWEEN(SYSDATE,'15-AUG-99')/12)||'Years' age FROM dual;

SELECT employee_id
		,first_name 
		,hire_date
		,ROUND(MONTHS_BETWEEN(SYSDATE hire_date)/12)||'year' "EXEP"
	FROM employees;
	WHERE ROUND(MONTHS_BETWEEN(SYSDATE ,hire_date)/12)>25;
	
--SELECT (SYSDATE-<DATE>)/365 FROM dual
SELECT SYSDATE 
,ADD_MONTHS(SYSDATE,3)		"ADD_01"
,ADD_MONTHS(SYSDATE,-3)     "ADD_02"
FROM dual;

SELECT SYSDATE,NEXT_DAY (SYSDATE 'Wednesday') FROM dual;

SELECT NEXT_DAY (SYSDATE,'Thursday') FROM dual;

SELECT SYSDATE , NEXT_DAY(SYSDATE+(5*7)'Wednesday') FROM dual;

SELECT SYSDATE , NEXT_DAY (ADD_MAONTHS(SYSDATE,2),'Wednasday') FROM dual;

SELECT LAST_DAY (SYSDATE) FROM dual;

--Write a query to display last 10 days txn 

SELECT * FROM txn_tb WHERE txn_dt BETWEEN SYSDATE -10 AND SYSDATE;

SELECT SYSDATE 
		,ROUND(SYSDATE,'MM')				R1
		,ROUND(TO_DATE('15-AUG-22'),'MM')	R2
		,TRUNC(SYSDATE,'MM')				T1
		,TRUNC(TO_DATE('15-AUG-22'),'MM')	T2
	FROM dual;
	
SELECT SYSDATE
	,ROUND(SYSDATE,'YY')
	,ROUND(SYSDATE-200,'YY')
FROM dual;

SELECT SYSDATE
	,TRUNC(SYSDATE,'YY')
	,TRUNC(SYSDATE-200,'YY')
FROM dual;

--Date MONTHS-Hire
--Date Year -Hire
















